<footer>
<p>Copyright &copy; <?=date('Y')?>-<?=date('y')+1?> Dav PG College Varanasi. All Rights Reserved | Developed by <a href="http://balajisoftwaresolution.com/" target="_blank">Balaji Software Solution</a></p>
</footer>
