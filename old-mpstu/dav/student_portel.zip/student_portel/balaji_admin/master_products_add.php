<?php   include("../con_base/functions.inc.php"); 
if(isset($_GET['edit']))
 {
$ty=$_GET['edit'];
$qry=mysql_query("select * from category where id='$ty' ")or die(mysql_error());
 $row=mysql_fetch_array($qry);
 }
if(isset($_POST['go']))
{
require_once("uploader.php"); 
if(isset($_FILES['uploaded_file']))
{
upload("../upload/category/");
}
mysql_query("insert into category set parent_id='".$_POST['country']."', name='".$_POST['name']."', weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."' , imname='$finame', show_on='".$_POST['show_on']."',  status=0 , descr='".$_POST['descr']."' , price='".$_POST['price']."', price_offer='".$_POST['price_offer']."'")or die(mysql_error());
$_SESSION['sess_msg']=" Add Successfully";
header("Location:master_products?parent=".$_POST['country']);
exit;
}
  if(isset($_POST['go2']))
{
require_once("uploader.php");
if(isset($_FILES['uploaded_file']))
 { upload("../upload/category/");  if($finame!="") { 
 $rw=mysql_query("select * from category where id='".$_POST['edit']."'");
 $rw1=mysql_fetch_array($rw)or die(mysql_error());
 $x=$rw1['imname'];
 unlink("../upload/category/".$x);  
 $q=mysql_query("update category set parent_id='".$_POST['country']."', name='".$_POST['name']."' , weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."' ,  imname='$finame', show_on='".$_POST['show_on']."' , descr='".$_POST['descr']."', price='".$_POST['price']."', price_offer='".$_POST['price_offer']."' where id='".$_POST['edit']."'")or die(mysql_error());
 header("Location: master_products?parent=".$_POST['country']); exit;
 } else {
 $q=mysql_query("update category set parent_id='".$_POST['country']."', name='".$_POST['name']."' , weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."'  ,  show_on='".$_POST['show_on']."' , descr='".$_POST['descr']."', price='".$_POST['price']."', price_offer='".$_POST['price_offer']."' where id='".$_POST['edit']."'")or die(mysql_error());
 $_SESSION['sess_msg']=" Updated Successfully";
 header("Location: master_products?parent=".$_POST['country']); exit ;
		} } }
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add / Update Product</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer" enctype="multipart/form-data">
    <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td width="36%" bgcolor="#FFFFFF" >Select Category : </td>
        <td width="64%" bgcolor="#FFFFFF" ><select name="country" class="textbox"  >
          <?php /*?>  <option value="0" <? if($_REQUEST['country']==0 || $row['parent_id']==0) echo "selected";?>>Top</option><?php */?>
<? $country_qry=mysql_query("select * from category where parent_id=24 order by name asc")or die(mysql_error());
 while($country_fetch=mysql_fetch_array($country_qry)) { ?>
            <option value="<? echo $country_fetch['id']?>" <? if($_REQUEST['parent']==$country_fetch['id'] || $row['parent_id']==$country_fetch['id']) echo "selected";?>><? echo normalall_filter($country_fetch['name'])?></option>
<?  $country_qry1=mysql_query("select * from category where parent_id='".$country_fetch['id']."' order by name asc")or die(mysql_error()); while($country_fetch1=mysql_fetch_array($country_qry1)) { ?>
            <option value="<? echo $country_fetch1['id']?>" <? if($_REQUEST['parent']==$country_fetch1['id'] || $row['parent_id']==$country_fetch1['id']) echo "selected";?>>&nbsp;&nbsp;&nbsp;--<? echo normalall_filter($country_fetch1['name'])?></option>
            <?  $country_qry2=mysql_query("select * from category where parent_id='".$country_fetch1['id']."' order by name asc")or die(mysql_error()); while($country_fetch2=mysql_fetch_array($country_qry2)) { ?>
            <option value="<? echo $country_fetch2['id']?>" <? if($_REQUEST['parent']==$country_fetch2['id'] || $row['parent_id']==$country_fetch2['id']) echo "selected";?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--<? echo normalall_filter($country_fetch2['name'])?></option>
            <? } } } ?>
          </select></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" >
            Name  :          
         <input name="weight" type="hidden"  id="cname2" size="50" value="<? if(isset($_GET['edit'] )) echo $row['weight'];  else echo stripslashes($_POST['weight'])	;?>" />           </td>
        <td bgcolor="#FFFFFF"><input name="name" type="text" class="textbox validate[required] text-input"  id="cname3" value="<? if(isset($_GET['edit'] )) echo $row['name'];  else echo stripslashes($_POST['name'])	;?>" size="50" /></td>
      </tr>


<tr>
        <td valign="top" bgcolor="#FFFFFF" >
           Specification :           </td>
        <td bgcolor="#FFFFFF"> <textarea name="pile_height" rows="5" class="textbox " id="cname"><? if(isset($_GET['edit'] )) echo $row['pile_height'];  else echo stripslashes($_POST['pile_height'])	;?></textarea></td>
      </tr>


      
      <tr>
       <td height="22" bgcolor="#FFFFFF" >Price</td>
       <td bgcolor="#FFFFFF"><input name="price" type="text"   id="price" value="<? if(isset($_GET['edit'] )) echo $row['price'];  else echo stripslashes($_POST['price'])	;?>" size="50" /></td>
      </tr>
      <tr>
       <td height="22" bgcolor="#FFFFFF" >Offer Price</td>
       <td bgcolor="#FFFFFF"><input name="price_offer" type="text" class="textbox validate[required] text-input"  id="price_offer" value="<? if(isset($_GET['edit'] )) echo $row['price_offer'];  else echo stripslashes($_POST['price_offer'])	;?>" size="50" /></td>
      </tr>
      <tr>
       <td height="22" colspan="2" bgcolor="#FFFFFF" >Full Description</td>
      </tr>
      <tr>
       <td height="22" colspan="2" bgcolor="#FFFFFF" ><textarea name="descr" cols="50" class="textbox validate[required] text-input" id="descr"><? if(isset($_GET['edit'] )) echo $row['descr'];  else echo stripslashes($_POST['descr'])	;?></textarea>
       <script type="text/javascript"> 

			CKEDITOR.replace( 'descr',{

				toolbar :

						[

							

							

						

							{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },

							{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', ] },

							{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },

							{ name: 'colors', items : [ 'TextColor','BGColor' ]}, 

							

							'/',

							{ name: 'document', items : [ 'Source','-','Preview','Print','-'] },

							{ name: 'tools', items : [ 'Maximize'] },

							{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },

							{ name: 'editing', items : [ 'Find','Replace','-','SpellChecker'] }, 

							{ name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','SpecialChar' ] },

							{ name: 'links', items : [ 'Link','Unlink','Anchor' ] }  

							

						],

	filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

	filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

	filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

	filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

	filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

	filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

});



            </script>
       </td>
      </tr>
      <tr>
        <td height="22" bgcolor="#FFFFFF" >Upload Image : </td>
        <td bgcolor="#FFFFFF"><input name="uploaded_file" type="file" class="textbox "  id="uploaded_file" /></td>
      </tr>
      <tr>
        <td height="22" colspan="2" align="center" bgcolor="#FFFFFF"><?php if($_REQUEST['edit']!='') { ?>
          <input name="edit" type="hidden" id="edit" value="<?php echo $_REQUEST['edit'];?>" />
          <input name="go2" type="submit" class="subm" id="go2" value="Update " />
          <? }  else  { ?>
          <input name="go" type="submit" class="subm" id="go" value="Add " />
          <? } ?>        </td>
      </tr>
    </table>
   <p>&nbsp;</p>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
