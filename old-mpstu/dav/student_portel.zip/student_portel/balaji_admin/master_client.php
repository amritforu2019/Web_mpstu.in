<?php   include("../con_base/functions.inc.php"); master(); ?>
<?

if(isset($_POST["upd"]))
{
require_once("uploader.php");
if(isset($_FILES['uploaded_file']))
{
upload("../upload/member/");
if($finame!="")
{ 
$where = ", img='$finame'";
}
}
$partyqry="update  `tbl_reg` set  `regno`='".$_POST["regno"]."' ,`doj` ='".$_POST["doj"]."',`title`='".$_POST["title"]."',`title2`='".$_POST["title2"]."',`name`='".$_POST["name"]."' ,`fname`='".$_POST["fname"]."' ,`trn`='".$_POST["trn"]."' ,`trntime`='".$_POST["trntime"]."' ,`dob` ='".$_POST["dob"]."',`grade`='".$_POST["grade"]."' ,`trnp`='".$_POST["trnp"]."' ,`doe`='".$_POST["doe"]."' ,`addr`='".$_POST["addr"]."' $where  where `id`='".$_POST["edit"]."'";

if(mysql_query($partyqry))
{
$_SESSION['msg']="<span style='color:green; font-size:14px;'>Record Updated Successfully</span>";
	?>
<script>
location.href="master_client";
</script>
<?php
}
exit;
}


if(isset($_POST["save"]))
{
require_once("uploader.php");
if(isset($_FILES['uploaded_file']))
{
upload("../upload/member/");
if($finame!="")
{ 
$where = ", img='$finame'";
}
}

$partyqry="INSERT INTO  `tbl_reg` set `regno`='".$_POST["regno"]."' ,`doj` ='".$_POST["doj"]."',`title`='".$_POST["title"]."',`title2`='".$_POST["title2"]."',`name`='".$_POST["name"]."' ,`fname`='".$_POST["fname"]."' ,`trn`='".$_POST["trn"]."' ,`trntime`='".$_POST["trntime"]."' ,`dob` ='".$_POST["dob"]."',`grade`='".$_POST["grade"]."' ,`trnp`='".$_POST["trnp"]."' ,`doe`='".$_POST["doe"]."' ,`addr`='".$_POST["addr"]."' $where  ";

if(mysql_query($partyqry))
{
$_SESSION['msg']="<span style='color:green; font-size:14px;'>Record Saved Successfully</span>";
?>
<script>
location.href="master_client";
</script>
<?php  } 
exit;
} 


if(($_REQUEST['del'])!=''){
mysql_query("delete from tbl_reg where id=".$_REQUEST['del']." ");
header("Location:master_client");
$_SESSION['msg']="<span style='color:green; font-size:14px;'>Record Deleted Successfully</span>";
exit;}



if($_REQUEST['edit']!='')
{
	$serchqry="select * from tbl_reg where id='".$_REQUEST['edit']."' ";
	$qs=mysql_query($serchqry);
	$editrow=mysql_fetch_array($qs);
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="modernizr.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="ddaccordion.js"></script>
<script>
function sbb(val)
{
	if(val!='')
	{
		location.href='master_product.php?brand='+val;
	}
}
</script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<link rel="stylesheet" type="text/css" href="codebase/dhtmlxcalendar.css">
<link rel="stylesheet" type="text/css" href="codebase/skins/dhtmlxcalendar_dhx_skyblue.css">
<script src="codebase/dhtmlxcalendar.js"></script>
<script>
var myCalendar;
function doOnLoad() {
    myCalendar = new dhtmlXCalendarObject(["doj", "dob", "doe"]);
}


</script>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body onLoad="doOnLoad()">
<?php include('header.php');?>
<div class="conten">
<h1> Registration Create / List</h1>
  <form action="" method="post"  enctype="multipart/form-data" name="productform" id="formID" class="formular validationEngineContainer">
    <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
     
      <tr>
        <td colspan="2" align="center"><?  echo $_SESSION['msg']; unset($_SESSION['msg']);?></td>
      </tr>
      <tr>
        <td width="48%">
        <select name="title" class="textbox validate[required] " id="title">
        <option value="" >..Select Title..</option>
<option value="Mr." <? if($editrow['title']=='Mr.') echo 'selected'?>>Mr.</option>
<option value="Miss" <? if($editrow['title']=='Miss') echo 'selected'?>>Miss</option>
<option value="Mrs." <? if($editrow['title']=='Mrs.') echo 'selected'?>>Mrs.</option>
        </select>
        <input name="edit" type="hidden" class="textbox" id="edit"   value="<?php echo $editrow['id']; ?>"/></td>
        <td width="52%"><input name="name" type="text" class="textbox validate[required] text-input" id="name"   value="<?php echo $editrow['name']; ?>"  placeholder="Enter Name" /></td>
      </tr>
      <tr>
        <td><select name="title2" class="textbox validate[required] " id="title2">
          <option value="" >..Select Title..</option>
          <option value="D/O" <? if($editrow['title2']=='D/O') echo 'selected'?>>D/O</option>
          <option value="W/O" <? if($editrow['title2']=='W/O') echo 'selected'?>>W/O</option>
        </select></td>
        <td><input name="fname" type="text" class="textbox validate[required] text-input" value="<?php echo $editrow['fname']; ?>" id="fname"  placeholder="Enter Father / Husband name" /></td>
      </tr>
      <tr>
        <td><input name="trn"  type="text" class="textbox validate[required] text-input" value="<?php echo $editrow['trn']; ?>" id="trn"  placeholder="Tranning In"/></td>
        <td><input name="trntime"  type="text" class="textbox validate[required] text-input" value="<?php echo $editrow['trntime']; ?>" id="trntime"  placeholder="Tranning Timing Like 6 Months/ 1 Year"/></td>
      </tr>
      <tr>
        <td><input name="dob" type="text" class="textbox validate[required,custom[date],past[NOW]]" value="<?php echo $editrow['dob']; ?>" id="dob"  placeholder="Enter Date Of Birth" /></td>
        <td><input name="grade" type="text" class="textbox validate[required] text-input" value="<?php echo $editrow['grade']; ?>" id="grade"  placeholder="Enter Grade Like A / B / C" /></td>
      </tr>
      <tr>
        <td><input name="trnp"  type="text" class="textbox validate[required] text-input" value="<?php echo $editrow['trnp']; ?>" id="trnp"  placeholder="Tranning Programm Details"/></td>
        <td><input name="doe" type="text" class="textbox validate[required,custom[date],past[NOW]]" value="<?php echo $editrow['doe']; ?>" id="doe"  placeholder="Enter Date Of Completion / Last Date" /></td>
      </tr>
      <tr>
        <td><input name="doj" type="text" 
        class="textbox  validate[required,custom[date],past[NOW]] text-input" value="<?php echo $editrow['doj']; ?>" id="doj"  placeholder="Enter Date Of Joining" /></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><textarea name="addr" rows="4"  class="textbox validate[required] text-input" id="addr"  placeholder="Full Address"><?php echo ($editrow['addr']); ?></textarea></td>
        <td valign="top"><input name="uploaded_file" type="file" class="textbox" id="uploaded_file" /></td>
      </tr>
      <tr>
        <td colspan="2" align="center"><?php if($_REQUEST['edit']!='') { ?>
          <input name="upd" type="submit" class="subm" id="upd"  value="Update : <?php echo $editrow['name']; ?>"/>
          <?php } else { ?>
          <input name="save" type="submit" class="subm" id="save"  value="Save"/>
        <?php } ?></td>
      </tr>
    </table>
 
  </form>
  <br />
  <form action="" method="post"  name="productsform" id="productsform" autocomplete='off'  >
    <table width="100%"  border="1"  cellpadding="5" cellspacing="0" align="center">
 
      <tr>
        <td  colspan="11" align="left" ><input name="txtserch" placeholder="Search by name or Father's name or Registration no." type="text" class="textbox" id="txtserch"  value="<?php echo $_POST['txtserch']?>"/>    
            <input name="searchdata" type="submit" class="subm" id="searchdata" value="Search" /></td>
      </tr>
      <tr class="bg1">
        <td   align="center" ><span class="style1">SN</span></td>
        <td   align="left">Cert_Reg_no.</td>
        <td   align="left">Name</td>
        <td align="left">Father / Husband Name</td>
        <td colspan="4" align="left"><span class="style1">Dates</span></td>
        <td  align="center" class="style1">Tranning Program Details</td>
        <td align="center" class="style1">Image</td>
        <td  align="center" class="style1">Action</td>
      </tr>
      <?php
	  if(isset($_POST['searchdata']))
	  {
	  $where=" where name like '%".$_POST['txtserch']."%' or fname like '%".$_POST['txtserch']."%' or regno like '%".$_POST['txtserch']."%'  ";
	  }
	   $q=1;
      	$qry=mysql_query("select * from tbl_reg $where ")or die(mysql_error()); 
		$counter=mysql_num_rows($qry); if($counter==1) { mysql_query("update tbl_reg set srno='10000' where  regno='' ");  }
		while($row=mysql_fetch_array($qry)){ extract($row);		
	  ?>
      <tr>
        <td align="left" valign="top" ><?php echo $q++; ?></td>
        <td align="left" valign="top" ><?php echo $row["regno"]; if($row["regno"]=='')
		{
		$rowd=mysql_fetch_array(mysql_query("select MAX(srno) AS idno from tbl_reg "));
		$regdata=$rowd['idno'];  $regdata++; $srno=$regdata; $regdata='MSBT-'.$regdata; 
		//echo "update tbl_reg set regno='$regdata',srno='$srno'  where id='".$row["id"]."' ";
		mysql_query("update tbl_reg set regno='$regdata',srno='$srno'  where id='".$row["id"]."' ");
		}
		?></td>
        <td align="left" valign="top" ><?php echo $row["name"]?></td>
        <td align="left" valign="top" ><?php echo $row["fname"]?></td>
        <td colspan="4" align="left" valign="top" >Date Of Birth : <?php echo date("d M Y",strtotime($row["dob"]));?><br /> Date Of Joining : <?php echo date("d M Y",strtotime($row["doj"]));?> <br /> Date Of Completion : <?php echo date("d M Y",strtotime($row["doe"]));?></td>
        <td align="left" valign="top" >Tranning in : <?php echo $row["trn"]?><br />Grade : <?php echo $row["grade"]?>, Time : <?php echo $row["trntime"]?><br />Tranning Programm : <?php echo $row["trnp"]?><br /></td>
        <td align="left" valign="top" ><a href="../upload/member/<?php echo $row["img"]?>" title="Click To View" target="_blank" > <img src="../upload/member/<?php echo $row["img"]?>"  alt="" height="70" /> </a></td>
        <td align="left" valign="top" ><a title="Delete Record" href="master_client?del=<?php echo $row["id"];?>" onClick="return del();"><img src="images/del.png" /></a>&nbsp;<a  title="Edit record" href="master_client?edit=<?php echo $row["id"];?>" ><img src="images/edit.png" /></a> &nbsp;<a target="_blank"  title="Print Certificate" href="../certificate?r=<?php echo enc($row["id"]);?>" >Print</a>  </td>
      </tr>
      
      <? }  ?>
    </table>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
