
<style type="text/css">
 
.style2 {color: #009900; font-size:22px;}
.style3 {color: #3300CC ; font-size:22px;}
 
</style><?php    include("../con_base/functions.inc.php"); 


  $name=trim($_REQUEST['pname']);
 $pid=trim($_REQUEST['pid']);
 
 
if( ($_REQUEST['edit'])=='')
{


$query2=mysql_query("SELECT * FROM category WHERE name LIKE '%$name%'  and parent_id='".$pid."'");
$datacount=mysql_num_rows($query2);
if($datacount>0)
{
$row=mysql_fetch_array($query2);
$q=mysql_query("update category set parent_id='".$pid."', name='".$pname."' WHERE name LIKE '%$name%'  and parent_id='".$pid."'")or die(mysql_error());
?>


<input value="<?=$row['id'];?>" type="hidden"  name="pid" id="pid"/>
<span class="style3">Data Modified</span>
<?
}
else
{
mysql_query("insert into category set parent_id='".$pid."', name='".$name."',  status=1 ")or die(mysql_error());
$catid=mysql_insert_id();
?>
<input value="<?=$catid;?>" type="hidden"  name="pid" id="pid"/>
<span class="style2">Data Inserted</span>
<? } } else { 
 
$q=mysql_query("update category set parent_id='".$pid."', name='".$name."' WHERE id ='".$_REQUEST['edit']."'")or die(mysql_error());
 ?><input value="<?=$_REQUEST['edit'];?>" type="hidden"  name="pid" id="pid"/>
<span class="style3">Data Updated</span><? }  ?>