<?php   include("../con_base/functions.inc.php"); 

if(isset($_GET['del']))
{
$arr=$_GET['del'];
if(mysql_num_rows(mysql_query("select id from category where parent_id='$arr'"))!=0)
{
$_SESSION['sess_msg']="First Delete sub-category linked with this category";
header("Location: category_list?parent=".$_REQUEST['parent']);exit;
}
else
{
$cn=mysql_query("select imname from category where id='$arr'")or die(mysql_error());
$cn1=mysql_fetch_array($cn);
if($cn1['imname']!='')
{
@unlink("../upload/category/".$cn1['imname']);
}
mysql_query("delete from category where id='$arr'")or die(mysql_error());
$_SESSION['sess_msg']="Category Deleted Successfully";
header("Location: category_list?parent=".$_REQUEST['parent']);exit;
} }

if(isset($_GET['ban']))
{
mysql_query("update category set status=0 where id=".$_GET['ban']);
$sess_msg="Category  banned Successfully";
$_SESSION['sess_msg']=$sess_msg;
header("Location: category_list?parent=".$_REQUEST['parent']);exit;
}

if(isset($_GET['unban']))
{
mysql_query("update category set status=1 where id=".$_GET['unban']);
$sess_msg="Category  Unbanned Successfully";
$_SESSION['sess_msg']=$sess_msg;
header("Location: category_list?parent=".$_REQUEST['parent']); exit;
}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

	
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
function load_page(val){ location.href='category_list?parent='+val;	return false; }
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Change / Update Menu Category</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer">
    <?
if($_REQUEST['parent']=="0") { $where="where parent_id=0"; }
 else if($_REQUEST['parent']!="") { $where=" where parent_id='".$_REQUEST['parent']."'  "; }	
 else { $where="where parent_id=0"; }
 //echo "select * from category   $where order by name asc";
 $q=mysql_query("select * from category   $where order by name asc");
 $count=mysql_num_rows($q);

				 ?>
    <table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="32"><select name="country" class="textbox" onChange="javascript:load_page(this.value);">
            <option value="0">Select Service Category</option>
            <?

					$country_qry=mysql_query("select * from category where parent_id=0 order by name asc")or die(mysql_error());

					while($country_fetch=mysql_fetch_array($country_qry))

					{

					?>
            <option value="<? echo $country_fetch['id']?>" <? if($_REQUEST['parent']==$country_fetch['id']) echo "selected"; ?>><? echo normalall_filter($country_fetch['name'])?></option>
            <?  $country_qry1=mysql_query("select * from category where parent_id='".$country_fetch['id']."' order by name asc")or die(mysql_error());

					while($country_fetch1=mysql_fetch_array($country_qry1))

					{

					?>
            <option value="<? echo $country_fetch1['id']?>" <? if($_REQUEST['parent']==$country_fetch1['id'] || $row['parent_id']==$country_fetch1['id']) echo "selected";?>>&nbsp;&nbsp;&nbsp;<? echo normalall_filter($country_fetch1['name'])?></option>
            <?  $country_qry2=mysql_query("select * from category where parent_id='".$country_fetch1['id']."' order by name asc")or die(mysql_error());

					while($country_fetch2=mysql_fetch_array($country_qry2))

					{

					?>
            <option value="<? echo $country_fetch2['id']?>" <? if($_REQUEST['parent']==$country_fetch2['id'] || $row['parent_id']==$country_fetch2['id']) echo "selected";?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo normalall_filter($country_fetch2['name'])?></option>
            <? } } } ?>
          </select></td>
        <td width="20%" valign="top">
        <? if($_REQUEST['parent']!='' && $_REQUEST['parent']!='0') { ?>   <input name="gone" type="button" class="subm" id="gone" value="Add New " onClick="javascript:window.location.href='category_add?parent=<? echo $_REQUEST['parent']?>&back=category_list?parent=<? echo $_REQUEST['parent']?>'" />
        <? } else{ ?>   <input name="gone" type="button" class="subm" id="gone" value="Add New" onClick="javascript:window.location.href='category_add?parent=<? echo $_REQUEST['parent']?>'" />
        <? } ?>     </td>
      </tr>
    </table>
    <? if($count!=0) { ?>
    <table width="90%" border="0" align="center" cellpadding="5" cellspacing="0" class="table">
      <tr>
        <td colspan="8" align="center" class="correct"><div align="center"><? echo stripslashes($_SESSION['sess_msg']); unset($_SESSION['sess_msg']);?></div></td>
      </tr>
      <tr   >
        <td  bgcolor="#add8f8" >SNo.</td>
        <td bgcolor="#add8f8" >  Name </td>
       <td align="center" bgcolor="#ADD8F8" >Image</td>
        <td  align="center" bgcolor="#add8f8" >Action</td>
        <td  bgcolor="#add8f8" >SNo.</td>
        <td  bgcolor="#add8f8" >  Name </td>
       <td  align="center" bgcolor="#ADD8F8" >Image</td>
        <td  align="center" bgcolor="#add8f8" >Action</td>
      </tr> <tr>
      <? $i=1; while($row=mysql_fetch_array($q)) { extract($row); ?>
     
        <td align="left" valign="top" bgcolor="#FFFFFF" ><?  echo $i;?>
        </td>
        <td valign="top" bgcolor="#FFFFFF" ><? if($row['parent_id']=='0') { ?><a href="category_list?parent=<?  echo normal_filter($id);?>"><?  echo normal_filter($name);?></a><? } else {?><?  echo normal_filter($name); } ?><br />
       <!-- Qty Pcz Amt : <?  echo normal_filter($amt3);?><br>
        Half Yr Pcz Amt : <?  echo normal_filter($amt6);?><br>
        One Yr Pcz Amt : <?  echo normal_filter($amt12);?>-->
        </td>
        <td align="center" valign="top" bgcolor="#FFFFFF" ><? if($imname!=''){?>
          <img src="../upload/category/<? echo $imname;?>" width="117" />
          <? } else echo "No Image"; ?></td>
        <td align="center" valign="top" bgcolor="#FFFFFF" >
        
        
        <? if($row['parent_id']!='0') { ?> 
        <a href=" <? if($row['parent_id']=='0') { ?>category_add?edit=<?  echo $id?>&parent=<? echo $parent_id;?><? } else{ ?>category_add?edit=<?  echo $id?>&parent=<? echo $parent_id;?>&back=category_list?parent=<? echo $parent_id;?><? } ?>"><img src="images/edit.png" alt="Edit Details" /></a>
        
       
         <a href="category_list?del=<?  echo $id?>&parent=<? echo $parent_id;?>" onClick="return del();"><img src="images/del.png" alt="Delete country_city" /></a>
          <?  if($status==0){?>
          <a href="category_list?unban=<?  echo $id?>&parent=<? echo $parent_id;?>" ><img src="images/not_verify.png" alt="Unban parent" /></a>
          <? }  else { ?>
          <a href="category_list?ban=<?  echo $id?>&parent=<? echo $parent_id;?>" ><img src="images/pro-verified-ok.png" alt="Ban parent" /></a>
          <? }  ?><!--<br>
          <a href="package_list?catid=<?  echo $id?>" >View Package</a>-->
          <br /> <?
          
  $reccnt=mysql_num_rows(mysql_query("select * from gal_img2 where pid='".$id."'"));  
		  ?>
          <a href="photoGallery2?pid=<?  echo $id?>" >Slider Img ( <?=$reccnt;?> )</a>
          <? } ?></td>
      
      <? if($i%2==0) echo '</tr><tr>'; $i++;} ?></tr>
    </table>
    <? }  else {?>
    <div align="center">Currently No Category Available in this parent category ..</span>
      <? }?>
    </div>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
