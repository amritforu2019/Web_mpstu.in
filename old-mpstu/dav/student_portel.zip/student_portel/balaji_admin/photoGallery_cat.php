<?php   include("../con_base/functions.inc.php"); ?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>

<title><?php echo $ADMIN_HTML_TITLE;?></title>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add update Gallery</h1>
  <form name="form1" method="post" action="photoGallery_cat_add">

                <br>   

				<table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">

                  <tr>

                    <td width="70%" height="32"> 

					</td>

                    <td width="15%" valign="middle"></td>

                    <td width="15%" align="right" valign="middle"><input name="gone" type="button" class="subm" onClick="location.href='photoGallery_cat_add'" value="Add Category">                    </td>

                  </tr>

                </table>

				<? 

				if(isset($_GET['del']))

				{

						$arr=$_GET['del']; 			

						mysql_query("delete from photogallery_cat where id='$arr'")or die(mysql_error());  

						$sess_msg="Photo Gallery Category Deleted Successfully";

						$_SESSION['sess_msg']=$sess_msg;

						header("Location: photoGallery_cat");

						exit; 

				}

					if(isset($_GET['ban']))

					{

						mysql_query("update photogallery_cat  set status=0 where id=".$_GET['ban']);

						$sess_msg="Photo Gallery Category Suspended Successfully";

						$_SESSION['sess_msg']=$sess_msg;

						header("Location: photoGallery_cat");

						exit;

					}

					if(isset($_GET['unban']))

					{

						mysql_query("update photogallery_cat set status=1 where id=".$_GET['unban']);

						$sess_msg="Photo Gallery Category Activated Successfully";

						$_SESSION['sess_msg']=$sess_msg;

						header("Location: photoGallery_cat");

						exit;

					} 

				  $q=mysql_query("select * from photogallery_cat order by id desc");

				  $count=mysql_num_rows($q);

				  if($count!=0)

				  {

				  ?> 

                <table width="85%" border="0" align="center" cellpadding="5" cellspacing="0" class="table">

                  <tr>

                    

                    <td colspan="5" align="center" class="correct"><div align="center"><? echo stripslashes($_SESSION['sess_msg']); ?></div></td>
                  </tr>

                  <tr   class="li">

                    <td align="left" bgcolor="#add8f8" class="heading"><span >&nbsp;&nbsp;SNo.</span></td>

                    <td height="27" align="left" bgcolor="#add8f8" class="heading"><span class="style1">Photo &nbsp;Gallery Category</span></td>

                    <td align="left" bgcolor="#add8f8" class="heading"><span class="style1">No. of Photos </span></td>

                    <td align="left" bgcolor="#add8f8" class="heading"><span class="style1">&nbsp;Action</span></td>
                  </tr>

                  <?

				$i=1;

				while($row=mysql_fetch_array($q))

				{

				extract($row);

				?>

                  <tr bgcolor="#F2F2F2" class="textli">

                    <td align="left" bgcolor="#FFFFFF" class="bodytext"><strong><? echo $i;?>.</strong></td>

                    <td align="left" nowrap bgcolor="#FFFFFF" class="bodytext" style="padding:10px;"><a href="photoGallery?pid=<?=$id;?>" style="color:#000;"><? if(strlen(normal_filter($name ))>200) { echo substr(normal_filter(strip_tags($name )),0,200)."...";} else { echo normal_filter(strip_tags($name ));}?></a> </td>

                    <td align="left" bgcolor="#FFFFFF" class="bodytext" style="padding:10px;"><? $reccnt=mysql_num_rows(mysql_query("select * from gal_img where pid='".$id."'")); if($reccnt>0) {?><a href="photoGallery?pid=<?=$id;?>" style="color:#000;"><? echo $reccnt;?></a><? } ?></td>

                  <td width="25%" align="left" bgcolor="#FFFFFF" class="bodytext">&nbsp;&nbsp;<a href="photoGallery_cat_add?edit=<?  echo $id?>" title="Edit Page"><img src="images/edit.png" alt="Edit Photo Gallery Category" width="20" height="20" border="0"></a> <a href="photoGallery_cat?del=<?  echo $id?>" onClick="return del();" title="Delete Photo Gallery Category"><img src="images/del.png" alt="Delete Category" width="18" height="18" border="0"></a>

                        <? if($status==0){?>

                      <a href="photoGallery_cat?unban=<?  echo $id?>" title="Activate Photo Gallery Category" ><img src="images/not_verify.png" alt="Unban Page" width="16" height="16" border="0"></a>

                      <? }

						  else { ?>

                        <a href="photoGallery_cat?ban=<?  echo $id?>" title="Suspend Photo Gallery Category" ><img src="images/pro-verified-ok.png" alt="Ban Page" width="14" height="14" border="0"></a>

                      <? } ?></td>
				  </tr>

                  <?

					$i++;

				} 

				?>
                 </table>

<? }  else {?>

                <div align="center"><span class="red"><strong>Currently 

                  No Photo Gallery Category Available, Please</strong></span> <span class="leftlinks"><a href="photoGallery_cat_add" class="headlinks">Add 

                    First</a></span>

                        <? }?>

                </div>

               </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>