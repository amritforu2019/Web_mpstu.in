<?php   include("../con_base/functions.inc.php"); if(isset($_GET['del']))
				{
						$arr=$_GET['del'];						
						mysql_query("delete from reg  where id='$arr'")or die(mysql_error());
						$sess_msg="visitor  Deleted Successfully";
						$_SESSION['sess_msg']=$sess_msg;
						header("Location: visitor_list");
						exit; 
				}
					if(isset($_GET['ban']))
					{
						mysql_query("update reg  set status=0 where id=".$_GET['ban']);
						$sess_msg="visitor Suspended Successfully";
						$_SESSION['sess_msg']=$sess_msg;
						header("Location: visitor_list");
						exit;
					}
					if(isset($_GET['unban']))
					{
						mysql_query("update reg set status=1 where id=".$_GET['unban']);
						$sess_msg="visitor Activated Successfully";
						$_SESSION['sess_msg']=$sess_msg;
						header("Location: visitor_list");
						exit;
					}?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Visitor  Management</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer">
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" class="table">
      <tr>
        <td colspan="8" align="center" ><div align="center"><? echo  stripslashes($_SESSION['sess_msg']); unset($_SESSION['sess_msg']); unset($_SESSION['errorclass']);?></div></td>
      </tr>
      <tr   class="li">
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">SNo.</td>
        <!--<td align="left" valign="top"  bgcolor="#add8f8" class="heading">Reg Details</td>
        --><td align="left" valign="top"  bgcolor="#add8f8" class="heading">Name / Title</td>
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">Contact Person</td>
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">Reg date / By</td>
      <!--  <td align="center" valign="top"  bgcolor="#add8f8" class="heading">Image</td>
      -->  <td align="center" valign="top"  bgcolor="#add8f8" class="heading">Action</td>
      </tr>
      <?   
				  
				  $q=mysql_query("select * from reg where r_typ='customer' order by id desc"); 
				  $count=mysql_num_rows($q);
				  if($count!=0)
				  {
				  
				$i=1;
				while($row=mysql_fetch_array($q))
				{
				extract($row);
				
				
				/*if($row['package_name']==''){ 
				$country_qry=mysql_query("select * from package where id='".$row['package']."'")or die(mysql_error());  
				$country_fetch=mysql_fetch_array($country_qry);
				  
				mysql_query("update reg set package_name='".$country_fetch['title']."', package_amt='".$country_fetch['descr']."' where id='".$row['id']."'  ") ;
				} */
				
				if($row['state_name']==''){ 
				$country_qry=mysql_query("select * from states where state_id='".$row['state']."'")or die(mysql_error());  
				$country_fetch=mysql_fetch_array($country_qry);				  
				mysql_query("update reg set state_name='".$country_fetch['state']."'  where id='".$row['id']."'  ") ;
				}  
				
				if($row['area_name']==''){ 
				$country_qry=mysql_query("select * from states_cities_area where pincode='".$row['area']."'")or die(mysql_error());  
				$country_fetch=mysql_fetch_array($country_qry);				  
				mysql_query("update reg set area_name='".$country_fetch['area_name']."'  where id='".$row['id']."'  ") ;
				}  

if($row['main_category']==''){ 
				$country_qry=mysql_query("select * from category where name='".$row['category']."'")or die(mysql_error());  
$country_fetch=mysql_fetch_array($country_qry);	
$country_qry2=mysql_query("select * from category where id='".$country_fetch['parent_id']."'")or die(mysql_error());  
$country_fetch2=mysql_fetch_array($country_qry2);	
					  
				mysql_query("update reg set main_category='".$country_fetch2['name']."'  where id='".$row['id']."'  ") ;
				} 
/*
if($row['doe']=='0000-00-00')
{
if($row['upgrade_dt']!='0000-00-00 00:00:00')
{
$country_qry=mysql_query("select * from package where id='".$row['package']."'")or die(mysql_error());  
$country_fetch=mysql_fetch_array($country_qry);	


$date = $row['upgrade_dt'];
$date = strtotime($date);
$date = strtotime("+".$country_fetch['days']." day", $date);
echo $doe=date('Y-m-d', $date);


mysql_query("update reg set doe='".$doe."'  where id='".$row['id']."'  ") ;

}
}

*/



				


?> 
				
				
				
				
      <tr bgcolor="#F2F2F2" class="textli">
        <td align="left" valign="top" bgcolor="#CCCDFD" class="bodytext"><? echo  $i;?></td>
        <!--<td align="left" valign="top" bgcolor="#EDFEE7" class="bodytext"><strong><?php echo $row['category'];?></strong> In <strong><?php echo $row['main_category'];?></strong><br>
        Package : <?php echo $row['package_name'];?> <br> Amount : <?php echo $row['package_amt'];?><br> Status : <? if($row['upgrade_dt']!='0000-00-00 00:00:00') { echo "Active on ".date("d M Y",strtotime($row['upgrade_dt']))."<br> Expire : ".date("d M Y",strtotime($row['doe'])); } else echo 'Not upgraded '; ?></td>-->
        <td align="left" valign="top"  bgcolor="#CCCDFD" class="bodytext"><?php echo $row['name'];?><br>
        Id :<?php echo $row['id'];?><br> Pass : <?php echo $row['pass'];?></td>
        <td align="left" valign="top"  bgcolor="#CCCDFD" class="bodytext"><?php /*?>/*<?php echo $row['contact_name'];?><br> <?php */?><?php echo $row['email'];?><br>
          <?php echo $row['contact'];?>
       <!-- <br>
        <a href="#" title="<?php echo $row['addr'];?> Area : <?php echo $row['area_name'];?> <?php echo $row['city'];?> [<?php echo $row['state_name'];?>] Pin :<?php echo $row['pin'];?>">View Address</a>--></td>
        <td align="left" valign="top"  bgcolor="#CCCDFD" class="bodytext"><?php echo date("d M Y",strtotime($row['r_dt']));?><br><?php echo $row['reg_by'];?><br>
          <?php echo $row['a_id'];?></td>
        <!--<td align="center" valign="top"  bgcolor="#EDFEE7" class="bodytext"><img src="../upload/provider/<?php echo $row['img'];?>" width="100" height="93" border="0"></td>-->
        <td align="center" valign="top"  bgcolor="#CCCDFD" class="bodytext"><!--<a href="news_add?edit=<?  echo  $id?>" title="Edit "><img src="images/edit.png" alt="Edit" width="20" height="20" border="0"></a>
          <a href="#"  title="View Profile "><img src="images/view.png" alt="Delete " width="21" height="21" border="0"></a>-->
         <a href="visitor_list?del=<?  echo  $id?>" onClick="return del();" title="Delete "><img src="images/del.png" alt="Delete " width="22" height="22" border="0"></a>
          <? if($status==0){?>
          <a href="visitor_list?unban=<?  echo  $id?>" title="Activate " ><img src="images/not_verify.png" alt="Unban " width="16" height="16" border="0"></a>
          <? }
						  else { ?>
          <a href="visitor_list?ban=<?  echo  $id?>" title="Suspend " ><img src="images/pro-verified-ok.png" alt="Ban " width="14" height="14" border="0"></a>
          <? } ?></td>
      </tr>
      <?
					$i++;
				} 
				?>
      <? }   else { ?>
      <tr bgcolor="#F2F2F2" class="textli">
        <td colspan="7" align="center" bgcolor="#FFFFFF" class="bodytext"> Currently No Data Available</td>
      </tr>
      <? }   ?>
    </table>
    
  </form>
</div>
<?php include('footer.php');
mysql_query("ALTER TABLE `reg` ADD `doe` DATE NOT NULL ; ");
?>
</body>
</html>
<? ob_end_flush(); ?>
