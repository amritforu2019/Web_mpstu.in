<?php   include("../con_base/functions.inc.php"); ?>
<?
if(isset($_GET['edit']))
{
$ty=$_GET['edit'];
$qry=mysql_query("select * from states_cities_area  where id='$ty' ")or die(mysql_error());
$row=mysql_fetch_array($qry);
 }

if(isset($_POST['go']))
{
mysql_query("INSERT INTO  `states_cities_area` set `area_name`= '".trim($_POST['area_name'])."' ,`pincode`= '".trim($_POST['pincode'])."' ,`city_id`= '".trim($_POST['city'])."' ,`state_id`= '".trim($_POST['state'])."' ,`flag`=1 ")or die(mysql_error());
$sess_msg="Details Added Successfully";
$_SESSION['sess_msg']=$sess_msg;
header("Location: area_list?state_id=".$_POST['state']."&city_id=".trim($_POST['city']));
exit;
}
if(isset($_POST['go2']))
{
$bn=stripslashes($_POST['edit']);
mysql_query("update `states_cities_area` set `area_name`= '".trim($_POST['area_name'])."' ,`pincode`= '".trim($_POST['pincode'])."' ,`city_id`= '".trim($_POST['city'])."' ,`state_id`= '".trim($_POST['state'])."'  where id='$bn'")or die(mysql_error());
$sess_msg="Details Updated Successfully";
$_SESSION['sess_msg']=$sess_msg;
header("Location: area_list?state_id=".$_POST['state']."&city_id=".trim($_POST['city']));
exit;
 }
	  

			  ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add /  Update Area List</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer">
    <table width="45%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td width="31%" height="22" >State Name :</td>
        <td width="69%"><select name="state" id="state" class="textbox" onChange="return onchangeajax2(this.value);">
          <option value="0">--Search By State--</option>
          <?php 
$sql="SELECT * FROM   states order by state";
$result =mysql_query($sql);
 while($rows=mysql_fetch_array($result)) { 

?>
          <option value="<?=$rows['state_id']?>" <?php if($rows['state_id']==$row['state_id']){?>selected<?php }?>><?php echo $rows['state'];?></option>
          <? } ?>
        </select><script>
function onchangeajax2(pid2)
 {
 xmlHttp=GetXmlHttpObject()
 if (xmlHttp==null)
 {
 alert ("Browser does not support HTTP Request")
 return
 }

 var url1="ajax_city.php"
 url1=url1+"?pid2="+pid2
 url1=url1+"&sid1="+Math.random()
 document.getElementById("city_update").innerHTML="Searching cities please wait..."
 if(xmlHttp.onreadystatechange=stateChanged)
 {
 xmlHttp.open("GET",url1,true)
 xmlHttp.send(null)
 return true;
 }
 else
 {
 xmlHttp.open("GET",url1,true)
 xmlHttp.send(null)
 return false;
 }
 }

 function stateChanged()
 {
 if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
 {
 document.getElementById("city_update").innerHTML=xmlHttp.responseText
 return true;
 }
 }

function GetXmlHttpObject()
 {
 var objXMLHttp=null
 if (window.XMLHttpRequest)
 {
 objXMLHttp=new XMLHttpRequest()
 }
 else if (window.ActiveXObject)
 {
 objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP")
 }
 return objXMLHttp;
 }
 
 </script></td>
      </tr>
      <tr>
        <td  >City name :</td>
        <td id="city_update"><select name="city" class="textbox" id="city"  >
          <option value="">City</option>
          <?php 
$sql="SELECT * FROM   states_cities where state_id='".$row['state_id']."' order by city";
$result =mysql_query($sql);
 while($rowd=mysql_fetch_array($result)) { 

?>
          <option value="<?=$rowd['city']?>" <?php if($rowd['city']==$row['city_id']){?>selected<?php }?>><?php echo $rowd['city'];?></option>
          <? } ?>
        </select></td>
      </tr>
      <tr>
        <td  >Area Name :</td>
        <td id="city_update"><input name="area_name" type="text" class="textbox"  id="area_name" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['area_name']); else echo  stripslashes($area_name);?>" ></td>
      </tr>
      <tr>
        <td  >Area Pin Code :</td>
        <td id="city_update"><input name="pincode" type="text" class="textbox"  id="pincode" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['pincode']); else echo  stripslashes($pincode);?>" ></td>
      </tr>
     
   <!-- <tr>

          <td height="22" > Delivery Charges : </td>

          <td><input name="del_charges" type="text" class="textbox"  id="del_charges" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['del_charges']); else echo  stripslashes($del_charges);?>" >
            Rs.</td>
        </tr>   -->
      <tr>
        <td height="22" colspan="2" align="center"><?php if($_REQUEST['edit']!='') { ?>
          <input name="edit" type="hidden" id="edit" value="<?php echo $_REQUEST['edit'];?>">
          <input name="go2" type="submit" class="subm" id="go2" value="Update area" >
          <? }  else  { ?>
          <input name="go" type="submit" class="subm" id="go" value="Add New" >
          <? } ?></td>
      </tr>
    </table>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
