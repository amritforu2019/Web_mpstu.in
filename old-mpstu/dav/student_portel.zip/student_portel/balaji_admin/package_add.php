<?php   include("../con_base/functions.inc.php"); 
if(isset($_GET['edit']))
{
$ty=$_GET['edit'];
$qry=mysql_query("select * from package  where id='$ty' ")or die(mysql_error());
$row=mysql_fetch_array($qry);	
}
if(isset($_POST['go']))
{
mysql_query("insert into package set  title='".addslashes($_POST['title'])."', posted_on=now(),  descr='".addslashes($_POST['descr'])."',  status=1 ,days='".trim($_POST['days'])."',category='".trim($_POST['category'])."',category_main='".trim($_POST['category_main'])."'")or die(mysql_error());
$_SESSION['sess_msg']="package Added Successfully";
header("Location: package_list");
exit;
}
if(isset($_POST['go2']))
{	 			 
mysql_query("update package set title='".addslashes($_POST['title'])."',posted_on=now(), descr='".addslashes($_POST['descr'])."',days='".trim($_POST['days'])."',category='".trim($_POST['category'])."',category_main='".trim($_POST['category_main'])."' where id='".$_POST['edit']."'")or die(mysql_error());
$_SESSION['sess_msg']="package Updated Successfully";			
header("Location: package_list");
exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add / Update package </h1>
  <form name="form1" method="post" action="package_add" id="formID" class="formular validationEngineContainer">
    <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
<?php /*?>  <!--    <tr>
       <td height="22" align="left" class="hometext">Select category :</td>
       <td><span class="form-group">
        <select name="category_main" class="textbox validate[required] text-input"  id="category_main" onChange="return change_cat(this.value);" >
         <option value=" ">Select Main Category</option>
         <? $country_qry=mysql_query("select * from category where parent_id=0 order by name asc")or die(mysql_error()); while($country_fetch=mysql_fetch_array($country_qry)) { ?>
         <option value="<? echo $country_fetch['id']?>" <? if($row['category_main']==$country_fetch['id']) echo "selected"; ?>><? echo normalall_filter($country_fetch['name'])?></option>
         <? } ?>
        </select>
       </span>
       <script>
function change_cat(cid)
 {
 xmlHttp=GetXmlHttpObject()
 if (xmlHttp==null)
 {
 alert ("Browser does not support HTTP Request")
 return
 }

 var url="ajax_cat_get.php"
 url=url+"?cid="+cid
 document.getElementById("refine_cat").innerHTML='Please wait..<img border="0" src="images/ajax-loader.gif" height="50px">'
 if(xmlHttp.onreadystatechange=stateChangedcc)
 {
 xmlHttp.open("GET",url,true)
 xmlHttp.send(null)
 return true;
 }
 else
 {
 xmlHttp.open("GET",url,true)
 xmlHttp.send(null)
 return false;
 }
 }

 function stateChangedcc()
 {
 if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
 {
 document.getElementById("refine_cat").innerHTML=xmlHttp.responseText
 return true;
 }
 }
 
 function GetXmlHttpObject()
 {
 var objXMLHttp=null
 if (window.XMLHttpRequest)
 {
 objXMLHttp=new XMLHttpRequest()
 }
 else if (window.ActiveXObject)
 {
 objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP")
 }
 return objXMLHttp;
 }

 
</script>
       </td>
      </tr>
      <tr>
       <td height="22" align="left" class="hometext">Select Sub category :</td>
       <td><span class="form-group" id='refine_cat'>
      <select name="category" class="textbox validate[required] text-input"  id="category">
       
        <?
if($row['category']!='0')
{
$country_qry=mysql_query("select * from category where  id='".$row['category']."' order by name asc")or die(mysql_error());
while($country_fetch=mysql_fetch_array($country_qry))
{
?>
<option value="<? echo $country_fetch['id']?>" <? if($_REQUEST['name']==$country_fetch['name']) echo "selected"; ?>><? echo normalall_filter($country_fetch['name'])?></option>
<? } } else echo ' <option value=" ">Select Sub Category</option>'; ?>
    </select>
    </span></td>
      </tr>--><?php */?>
      <tr>
        <td width="28%" height="22" align="left" class="hometext">Package Title :</td>
        <td width="72%"><input name="title" type="text" class="textbox validate[required] text-input" id="title" size="50" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['title']); else echo  stripslashes($title);?>">
          <input type="hidden" value="<?php echo $_REQUEST['edit']?>" name="edit" id="edit"></td>
      </tr>
      <tr>
        <td height="22" align="left" class="hometext" >Validity Days : </td>
        <td height="22" align="left" class="hometext" ><input name="days" type="text" class="textbox validate[required] text-input" id="days" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['days']); else echo  stripslashes($days);?>
"></td>
      </tr>
     <?php /*?> <tr>
        <td height="22" align="left" class="hometext" >Amount :</td>
        <td height="22" align="left" class="hometext" ><input name="descr" type="text" class="textbox validate[required] text-input" id="descr" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['descr']); else echo  stripslashes($descr);?>
"></td>
      </tr><?php */?>
     
      <tr>
        <td height="22" colspan="2" align="center"><?php if($_REQUEST['edit']!='') { ?>
          <input name="go2" type="submit" class="subm" id="go2" value="Update  " >
          <? }  else  { ?>
          <input name="go" type="submit" class="subm" id="go" value="Add " >
          <? } ?></td>
      </tr>
    </table>
 </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
