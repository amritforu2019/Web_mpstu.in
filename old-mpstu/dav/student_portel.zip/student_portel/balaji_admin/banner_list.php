<?php   include("../con_base/functions.inc.php");  master();?>
 <?
					  if(isset($_GET['dele']))
					  {
					  $u=mysql_query("select * from flash_images where id=".$_GET['dele']);
					  $u1=mysql_fetch_array($u);
					  $x=$u1['blocation'];
					  unlink("../upload/flash_images/$x"); 
					  mysql_query("delete from flash_images where id=".$_GET['dele']);
					 header("Location: banner_list");
					 $_SESSION['sess_msg']="<span style='color:red; font-size:14px;'>Image deleted successfully</span>";
					 exit; 
					  }
						$qry=mysql_query("select * from flash_images  order by id desc");
						$reccnt=mysql_num_rows($qry);
				  ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Manage Slider Images</h1>
  <form name="form1" method="post" action="banner_add.php" id="formID" class="formular validationEngineContainer">
                   
                    <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
                      <tr>
                        <td class="red" align="center"><?  echo $_SESSION['sess_msg']; unset($_SESSION['sess_msg']);?></td>
                      </tr>
                      <tr>
                        <td align="right" class="smalltext"><input name="type" type="hidden" value="1" />
                        
                        <input name="add" type="submit" class="subm" id="add" value="Add New Image" /></td>
                      </tr>
                    </table>
                    <TABLE width="90%" border="0" align="center" cellpadding="5"  >
                      <TBODY>
                        <TR>
                          <?  if($reccnt!=0){ $k=1; 
					while($row=mysql_fetch_array($qry)){ ?>
                    <TD><TABLE width=160 border=0 align=center cellpadding="5" cellSpacing=0>
<TBODY>
                                <TR>
                                  <TD align=center><SPAN class=style5><IMG src="../upload/flash_images/<? echo $row['blocation'];?>"  alt="<? echo $row['alttag']; ?>" height="200" border="1" /></SPAN> <a href="banner_list.php?unpopular=<? echo $row['id'];?>"> </a><br />
                                  <div align="center"><? echo normal_filter($row['burl']);?></div></TD>
                                </TR>
                                <TR>
                                  <TD align=middle>
                                    <div align="center"> <a href="banner_add?edit=<? echo $row['id'];?>&type=<? echo $_REQUEST['type']?>"><img src="images/edit.png" alt="Edit Produt Details" width="20" height="20" border="0" /></a>
                                    
                                     <a href="banner_list?dele=<? echo $row['id'];?>&type=<? echo $_REQUEST['type']?>" onClick="return del();"><img src="images/del.png" alt="Delete Infrastructure/Event" width="18" height="18" border="0" /></a> <br />
                                    </div></TD>
                                </TR>
                              </TBODY>
                            </TABLE></TD>
                          <?  if($k%1==0){?>
                        </tr>
                        <tr>
                          <?php }?>
                          <?php $k++;
								 }  } 
		?>
                        </TR>
                      </TBODY>
                    </TABLE>
              <table border="0" align="center" cellpadding="5" cellspacing="0">
<tr>
                        <td align="center" ><?   if($reccnt==0) { ?>
                          <span class="red">No Images Available .... Please <a href="banner_add.php?yahoo=sf" class="boldlisting">Add 
                          First </a> </span>
                          <?
		}?></td>
                      </tr>
              </table>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
