<?php   include("../con_base/functions.inc.php");  master();
if(isset($_REQUEST['page_id']))
{
$qry=mysql_query("select * from content where id='".$_REQUEST['page_id']."'")or die(mysql_error());
$row=mysql_fetch_array($qry);}

if(isset($_REQUEST['update'])){
require_once("uploader.php");
if(isset($_FILES['uploaded_file']))
{
upload("../upload/flash_images/");
if($finame!="")
{ 
$where = ", img='$finame'";
}
}
mysql_query("update content set content='".addslashes($_POST['content'])."',title='".addslashes($_POST['title'])."',last_edit=now() $where where id='".$_POST['hidid']."'")or die(mysql_error()); 
$_SESSION['sess_msg']="<span style='color:green; font-size:14px;'>Content updated successfully..</span>";
header("Location:content_list.php");
exit;
}

if(isset($_REQUEST['update2'])){
mysql_query("insert into  content set title='".addslashes($_POST['t1'])."',last_edit=now(),page='".addslashes($_POST['p1'])."' ")or die(mysql_error()); 
header("Location:content_list");
exit;
}

if(isset($_REQUEST['imgr'])){
	
$qry=mysql_query("select * from content where id='".$_REQUEST['imgr']."'")or die(mysql_error());
$row=mysql_fetch_array($qry);

unlink("../upload/flash_images/".$row['img']);


mysql_query("update content set img=''  where id='".$_REQUEST['imgr']."'")or die(mysql_error()); 
$_SESSION['sess_msg']="<span style='color:green; font-size:14px;'>Image Removed successfully..</span>";
header("Location:content_list");
exit;
}


if(isset($_REQUEST['del_page_id'])){
	
$qry=mysql_query("select * from content where id='".$_REQUEST['imgr']."'")or die(mysql_error());
$row=mysql_fetch_array($qry);

unlink("../upload/flash_images/".$row['img']);


mysql_query("delete from content  where id='".$_REQUEST['del_page_id']."'")or die(mysql_error()); 
$_SESSION['sess_msg']="<span style='color:green; font-size:14px;'>Page Removed successfully..</span>";
header("Location:content_list");
exit;
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Change / Update Pages</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer" enctype="multipart/form-data">

					  <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
					  	<? if($_SESSION['sess_msg']) {?>
					  <tr>
							<td height="10" colspan="2"></td>
						</tr>
						<tr> 
						  <td colspan="2" align="center" class="correct">
							 <? echo $_SESSION['sess_msg']; $_SESSION['sess_msg']='';  ?>						  </td>
						</tr>
						<? } ?>
						<tr><td height="10" colspan="2"></td></tr>  
						<? if(isset($_REQUEST['page_id'])){ ?> 
						
						<tr> 
						  <td width="27%">Page Title :</td>
						  <td width="73%"> <input name="title" type="text" class="textbox" id="title" size="80" value="<? if(isset($_GET['page_id'])) echo stripslashes($row['title']); else echo stripslashes($_POST['title']);?>"></td>
						</tr>
                        
                        <tr> 
						  <td>Image If Needed :</td>
						  <td> <label for="uploaded_file"></label>
<input name="uploaded_file" type="file" class="textbox" id="uploaded_file"></td>
						</tr>
						<tr> 
						   <td colspan="2">&nbsp;</td>
						</tr>
						<tr> 
						  <td colspan="2">
							<textarea name="content"  id="content"><? if(isset($_GET['page_id'])) echo stripslashes($row['content']); else echo stripslashes($_POST['content']);?></textarea>
                        <script type="text/javascript"> 

			CKEDITOR.replace( 'content',{

				toolbar :

						[

							

							

						

							{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },

							{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', ] },

							{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },

							{ name: 'colors', items : [ 'TextColor','BGColor' ]}, 

							

							'/',

							{ name: 'document', items : [ 'Source','-','Preview','Print','-'] },

							{ name: 'tools', items : [ 'Maximize'] },

							{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },

							{ name: 'editing', items : [ 'Find','Replace','-','SpellChecker'] }, 

							{ name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','SpecialChar' ] },

							{ name: 'links', items : [ 'Link','Unlink','Anchor' ] }  

							

						],

	filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

	filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

	filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

	filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

	filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

	filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

});



            </script>
							
							<input type="hidden" name="hidid" value="<? echo $_REQUEST['page_id']; ?>">						  </td>
						</tr>
						<tr> 
						  <td height="44" colspan="2" align="center"><input name="update" type="submit" class="subm" id="update2" onClick="return chk();" value="Update Content"></td>
					    </tr>
					  </table>
						<? } else { ?>
					 <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#FFFFFF"> 
				    <tr> 
                      <td width="7%" align="center"  bgcolor="#add8f8">SNo.</td>
                      <td width="34%"  bgcolor="#add8f8" >Page</td>
<td width="21%" align="center"  bgcolor="#add8f8">Img</td>
					  <td width="27%" align="center"  bgcolor="#add8f8">Last Edited</td>
                      <td width="11%" align="center"  bgcolor="#add8f8">Action</td>
                    </tr>
                   <?php
				   $query_content=mysql_query("select * from content order by page asc");
				   $reccnt=mysql_num_rows($query_content);
				   $k=1; while($content_res=mysql_fetch_array($query_content)){
				   @extract($content_res);?>
				    <tr > 
                      <td align="center" > 
                        <?php echo $k;?>.                      </td>
                      <td><a href="content_list.php?page_id=<?=$id;?>" title="Edit Content" style="color:#000;"><?php echo ucfirst($content_res['title']);?></a></td>
<td align="center"><?php if($content_res['img']!='') { ?><img src="../upload/flash_images/<?php echo $content_res['img']; ?>" height="60" /> <br/>
  <a href="content_list.php?imgr=<?=$id;?>">Remove Image</a><?php } else echo 'No Image'; ?></td>
					  <td align="center"> <?php echo date_dmy($content_res['last_edit']);?></td>
                      <td align="center"> <a href="content_list.php?page_id=<?=$id;?>"><img src="images/edit.png" alt="Edit Details" width="20" height="20" border="0"></a>
                    <!-- <? if($id>20) {?> <a href="content_list.php?del_page_id=<?=$id;?>" onClick="return del()"><img src="images/but_delete_small.gif" alt="Delete Details" width="22" height="22" border="0"></a>   <? } ?> -->                  </td>
                    </tr>
					<?php $k++; } ?>  
                  </table>
				 <? } ?> 
       
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>