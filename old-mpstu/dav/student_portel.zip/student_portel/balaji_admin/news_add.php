<?php   include("../con_base/functions.inc.php"); 
if(isset($_GET['edit']))
{
$ty=$_GET['edit'];
$qry=mysql_query("select * from news  where id='$ty' ")or die(mysql_error());
$row=mysql_fetch_array($qry);	
}
if(isset($_POST['go']))
{
mysql_query("insert into news set  title='".addslashes($_POST['title'])."', posted_on=now(),  descr='".addslashes($_POST['descr'])."',  status=1")or die(mysql_error());
$_SESSION['sess_msg']="News Added Successfully";
header("Location: news_list");
exit;
}
if(isset($_POST['go2']))
{	 			 
mysql_query("update news set title='".addslashes($_POST['title'])."',posted_on=now(), descr='".addslashes($_POST['descr'])."' where id='".$_POST['edit']."'")or die(mysql_error());
$_SESSION['sess_msg']="News Updated Successfully";			
header("Location: news_list");
exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add / Update News &amp; events</h1>
  <form name="form1" method="post" action="news_add" id="formID" class="formular validationEngineContainer">
    <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td width="12%" height="22" class="hometext"><div align="right" class="smalltext style1">
            <div align="right">Title :</div>
          </div></td>
        <td width="88%"><input name="title" type="text" class="textbox validate[required] text-input" id="title" size="50" value="<? if(isset($_GET['edit'] )) echo  stripslashes($row['title']); else echo  stripslashes($title);?>">
          <input type="hidden" value="<?php echo $_REQUEST['edit']?>" name="edit" id="edit"></td>
      </tr>
      <tr>
        <td height="22" colspan="2" align="center" class="hometext" >Description </td>
      </tr>
      <tr  >
        <td height="22" colspan="2" align="center" ><textarea name="descr" id="descr" class="textbox validate[required] text-input"><? if(isset($_GET['edit'] )) echo  stripslashes($row['descr']); else echo  stripslashes($descr);?>
</textarea>
          <script type="text/javascript"> 

			CKEDITOR.replace( 'descr',{

				toolbar :				[

												{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },

							{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', ] },

							{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },

							{ name: 'colors', items : [ 'TextColor','BGColor' ]}, 

							

							'/',

							{ name: 'document', items : [ 'Source','-','Preview','Print','-'] },

							{ name: 'tools', items : [ 'Maximize'] },

							{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },

							{ name: 'editing', items : [ 'Find','Replace','-','SpellChecker'] }, 

							{ name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','SpecialChar' ] },

							{ name: 'links', items : [ 'Link','Unlink','Anchor' ] }  

							

						],

	filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

	filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

	filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

	filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

	filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

	filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

});



            </script>
        </td>
      </tr>
      <tr>
        <td height="22" colspan="2" align="center"><?php if($_REQUEST['edit']!='') { ?>
          <input name="go2" type="submit" class="subm" id="go2" value="Update  New &amp; Events" >
          <? }  else  { ?>
          <input name="go" type="submit" class="subm" id="go" value="Add New &amp; Events" >
          <? } ?></td>
      </tr>
    </table>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
