<?php 
require_once("../con_base/functions.inc.php");

if(isset($_POST["upd"]))
{
$partyqry="update `bank` set `name`='".$_POST["name"]."' ,`email`='".$_POST["email"]."' ,`contact`='".($_POST["contact"])."' ,`dt`='".date("Y-m-d")."' , `addr`='".$_POST["addr"]."',sold_in ='".$_POST["sold_in"]."',c_per ='".$_POST["c_per"]."',cst ='".$_POST["cst"]."',tin ='".$_POST["tin"]."',`contact2`='".($_POST["contact2"])."' ,`contact3`='".($_POST["contact3"])."'   where `id`='".$_POST["edit"]."'";

if(mysql_query($partyqry))
{
	?>
<script>
location.href="master_bank";
</script>
<?php
}
}


if(isset($_POST["save"]))
{
$partyqry="INSERT INTO `bank` set `name`='".$_POST["name"]."' ,`email`='".$_POST["email"]."' ,`contact`='".($_POST["contact"])."' ,`dt`='".date("Y-m-d")."' , `addr`='".$_POST["addr"]."',sold_in ='".$_POST["sold_in"]."' ,c_per ='".$_POST["c_per"]."',cst ='".$_POST["cst"]."',tin ='".$_POST["tin"]."', `contact2`='".($_POST["contact2"])."' ,`contact3`='".($_POST["contact3"])."'";

if(mysql_query($partyqry))
{
?>
<script>
location.href="master_bank";
</script>
<?php  } } 
if(($_REQUEST['del'])!='')
{
$arr=$_REQUEST['del'];
$qry="delete from bank where id=".$arr."";
mysql_query($qry);
?><script>
location.href='master_bank';
</script><?php }
if($_REQUEST['edit']!='')
{
	$serchqry="select * from bank where id='".$_REQUEST['edit']."' ";
	$qs=mysql_query($serchqry);
	$editrow=mysql_fetch_array($qs);
	
}
?> 

  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="modernizr.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="ddaccordion.js"></script>

<script>
function sbb(val)
{
	if(val!='')
	{
		location.href='master_bank?brand='+val;
	}
}
</script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>


</head>
<body>
<?php include('header.php');?>
    <div class="conten">
    <h1>Bank Ac Create / List</h1>
    <form action="" method="post"  name="productform" id="productform" autocomplete='off'  >
   
     <table width="70%" height="121" border="1"  cellpadding="5" cellspacing="0" align="center">
                           
                            
                            
                            <tr >
                              <td width="168" align="left" > Bank Name</td>
                              <td width="241" align="left" ><input name="name" type="text" class="textbox" id="name" required  value="<?php echo $editrow['name']; ?>"/>
                              <input name="edit" type="hidden" class="textbox" id="edit"   value="<?php echo $editrow['id']; ?>"/></td>
                               <td width="162" align="left" >Account no</td>
                              <td width="225" align="left" ><input name="contact" required type="number" class="textbox" value="<?php echo $editrow['contact']; ?>" id="contact"></td>
                            </tr>
                            
                            <tr >
                              <td height="45" align="left" >Branch Address</td>
                              <td align="left" ><input name="addr"   type="text"  value="<?php echo ($editrow['addr']); ?>" class="textbox" id="addr" /></td>
                              <td align="left" >IFSC</td>
                              <td align="left" ><input name="contact2"  type="text" class="textbox" value="<?php echo $editrow['contact2']; ?>" id="contact2" /></td>
                            </tr>
                           
                            
                              
                              <tr >
                                <td height="36" >Account Name</td>
                                <td height="36" ><input name="c_per" type="text" required="required" class="textbox" value="<?php echo $editrow['c_per']; ?>" id="c_per" /></td>
                                <td height="36" >Other Info</td>
                                <td height="36" colspan="2" ><input name="contact3"  type="text" class="textbox" value="<?php echo $editrow['contact3']; ?>" id="contact3" /></td>
                              </tr>
                              
                              <tr >
                              <td height="36" colspan="5" ><center>
                              <?php if($_REQUEST['edit']!='') { ?>
                              <input name="upd" type="submit" class="subm" id="upd"  value="Update Bank : <?php echo $editrow['name']; ?>"/>
                              <?php } else { ?> <input name="save" type="submit" class="subm" id="save"  value="Save Bank"/> <?php } ?>
                              </center></td>
                              
                              </tr>
                             
      </table>
                          
   	  </form>
                      
                      <br />      
                                <form action="" method="post"  name="productsform" id="productsform" autocomplete='off'  >            
     <table width="80%"  border="1"  cellpadding="5" cellspacing="0" align="center">
      <!--<tr >
                              
                              <td colspan="2" >&nbsp;</td>
                              <td colspan="3" ><input name="txtserch" placeholder="Search by name " type="text" class="textbox" id="txtserch"  value="<?php echo $_POST['txtserch']?>"/></td>
                              <td colspan="2" ><input name="searchdata" type="submit" class="subm" id="searchdata" value="Search" /></td>
                              </tr>-->
      <tr>
        <td height="28" colspan="2" align="right" >Search By Bank name /Ac no. : </td>
        <td width="30%" height="28" align="left" ><input name="txtserch" placeholder="Search by name or contact no" type="text" class="textbox" id="txtserch"  value="<?php echo $_POST['txtserch']?>"/></td>
        <td height="28" align="left" ><input name="searchdata" type="submit" class="subm" id="searchdata" value="Search" /></td>
        <td height="28" align="center" >&nbsp;</td>
       </tr>
      <tr class="bg1">
                                        <td width="4%" height="28" align="center" ><span class="style1">SN</span></td>
                                        <td width="32%" align="left"><span class="style1">Bank Name</span></td>
                                        <td align="left" class="style1">Account details</td>
                                        <td width="25%" align="left" class="style1">Address</td>
                  <td width="9%" align="center" class="style1">Action</td>
       </tr>
                                      
                          <?php 
				
			/*	if($_REQUEST['brand']!='')
			 {
				 if($_REQUEST['brand']!='0')
				 {
				 $where= " where brand = '".$_REQUEST['brand']."' " ;
				 }
			 }
			 
			 	if(isset($_POST['searchdata']))
			 {
				 $where= " where name like  '%".$_POST['txtserch']."%' or pcode like  '%".$_POST['txtserch']."%'  " ;
			 }*/
			 if(isset($_POST['searchdata']))
			 {
				 $where= " where name like  '%".$_POST['txtserch']."%' or contact like  '%".$_POST['txtserch']."%'  " ;
			 }
			 
						$serchqry="select * from bank $where ";
						$q=0;
						
							$qs=mysql_query($serchqry);
							while($row=mysql_fetch_array($qs))
							{
								$q=$q+1;
								/*if($row["pcode"]=='')
								{
									mysql_query("update product set pcode='P-".$row["id"]."' where id='".$row["id"]."' ");
								}*/
								?><tr>
                            <td align="center" ><?php echo $q ?></td>
                            <td align="left" ><?php echo $row["name"]?> [<?php echo $row["c_per"]?>]</td>
                            <td align="left" ><?php echo $row["contact"]?>, <?php echo $row["contact2"]?>, <?php echo $row["contact3"]?></td>
                            <td align="left" ><?php echo $row["addr"]?></td>
                            <td align="center" ><a title="Delete Record" href="master_bank?del=<?php echo $row["id"];?>" onClick="return del();"><img src="images/del.png" /></a>&nbsp;<a title="Edit record" href="master_bank?edit=<?php echo $row["id"];?>" ><img src="images/edit.png" /></a></td></tr><?php
				}
			
				
						?>
                    
                        
      </table>
                         	

                       
	  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
