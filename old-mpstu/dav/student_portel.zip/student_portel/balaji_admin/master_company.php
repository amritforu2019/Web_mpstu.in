<?php 
require_once("config/functions.inc.php");
validate_admin();
if(isset($_POST["upd"]))
{
$partyqry="update `admin_login` set `comp_name`='".$_POST["comp_name"]."' ,`user`='".$_POST["user"]."' ,`pass`='".($_POST["pass"])."' ,user_name='".$_POST["user_name"]."' , cst='".$_POST["cst"]."', tin='".$_POST["tin"]."', descri='".$_POST["descri"]."',cont='".$_POST["cont"]."'  where `id`='".$_POST["edit"]."'";

if(mysql_query($partyqry))
{
	?>
<script>
location.href="master_company.php";
</script>
<?php
}
}


if(isset($_POST["save"]))
{
 $partyqry="INSERT INTO `admin_login` set `comp_name`='".$_POST["comp_name"]."' ,`user`='".$_POST["user"]."' ,`pass`='".($_POST["pass"])."' ,`cdt`='".date("Y-m-d")."' , `year`='".$_POST["year"]."', user_name='".$_POST["user_name"]."' , cst='".$_POST["cst"]."', tin='".$_POST["tin"]."', descri='".$_POST["descri"]."' ,cont='".$_POST["cont"]."'";

if(mysql_query($partyqry))
{
?>
<script>
location.href="master_company.php";
</script>
<?php  } } 
if(isset($_REQUEST['del']))
{
$arr=$_REQUEST['del'];
$qry="delete from product where id=".$arr."";
if(mysql_query($qry))
{
mysql_query("delete from stock where pid=".$arr."");
?><script>
location.href='master_product.php';
</script><?php }}
if($_REQUEST['edit']!='')
{
	$serchqry="select * from admin_login where id='".$_REQUEST['edit']."' ";
	$qs=mysql_query($serchqry);
	$editrow=mysql_fetch_array($qs);
	
}
?> 

  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="modernizr.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="ddaccordion.js"></script>

<script>
function sbb(val)
{
	if(val!='')
	{
		location.href='master_product.php?brand='+val;
	}
}
</script>
<script src="nic/nicEdit.js" type="text/javascript"></script>
<script type="text/javascript">
bkLib.onDomLoaded(function() {
	
	new nicEditor({maxHeight : 100}).panelInstance('descria');
});
</script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>


</head>
<body>
<?php include('header.php');?>
    <div class="conten">
    <h1>Company Create / List</h1>
    <form action="" method="post"  name="productform" id="productform" autocomplete='off'  >
   
     <table width="70%" height="82" border="1"  cellpadding="5" cellspacing="0" align="center">
                           
                            <tr >
                              <td width="157" align="left" >Year</td>
                              <td width="243" align="left" >
                              <select name="year" class="textbox" id="year">
                               
<option  value="<?php echo $current_year+0;?>-<?php echo $current_year_small+1;?>"><?php echo $current_year+0;?>-<?php echo $current_year_small+1;?></option>
                                
                              </select>
                              </td>
                               <td align="left" >Creation date</td>
                              <td width="247"  colspan="2" align="left" ><?php if($editrow['cdt']!='') {   echo date("F d Y",strtotime($editrow['cdt'])); }else {  echo date("F d Y"); } ?></td>
                            </tr>
                            
                            <tr >
                              <td width="157" align="left" >Company Name</td>
                              <td align="left" ><input name="comp_name" type="text" class="textbox" id="comp_name" required  value="<?php echo $editrow['comp_name']; ?>"/>
                              <input name="edit" type="hidden" class="textbox" id="edit"   value="<?php echo $editrow['id']; ?>"/></td>
                               <td width="149" align="left" >US No.</td>
                              <td colspan="2" align="left" ><input name="user" type="text" required class="textbox" id="user" value="<?php echo $editrow['user']; ?>"></td>
                            </tr>
                            
                            <tr >
                              <td align="left" >User Name</td>
                              <td align="left" ><input name="user_name" type="text" class="textbox" value="<?php echo $editrow['user_name']; ?>" id="user_name" /></td>
                              <td align="left" >PS No.</td>
                              <td colspan="2" align="left" ><input name="pass" required  type="text"  value="<?php echo ($editrow['pass']); ?>" class="textbox" id="pass" /></td>
                            </tr>
                            <tr >
                              <td align="left" >TIN No.</td>
                              <td align="left" ><input name="tin" type="text" class="textbox" value="<?php echo $editrow['tin']; ?>" id="tin" /></td>
                              <td align="left" >CST No.</td>
                              <td colspan="2" align="left" ><input name="cst" type="text" class="textbox" value="<?php echo $editrow['cst']; ?>" id="cst" /></td>
                            </tr>
                            <tr >
                              <td colspan="5" align="center" >Address &amp; Description</td>
                            </tr>
                            <tr >
                              <td colspan="5" align="center" ><textarea name="descri" rows="4" class="textbox"  id="descri"><?php echo $editrow['descri']; ?></textarea></td>
                            </tr>
                            <tr >
                              <td colspan="5" align="center" >Contacts</td>
                            </tr>
                            <tr >
                              <td colspan="5" align="center" ><textarea name="cont" rows="4" class="textbox"  id="cont"><?php echo $editrow['cont']; ?></textarea></td>
                            </tr>
                           
                            
                              <tr >
                              <td height="36" colspan="6" ><center>
                              <?php if($_REQUEST['edit']!='') { ?>
                              <input name="upd" type="submit" class="subm" id="upd"  value="Update Company : <?php echo $editrow['comp_name']; ?>"/>
                              <?php } else { ?> <input name="save" type="submit" class="subm" id="save"  value="Save Company"/> <?php } ?>
                              </center></td>
                              
                              </tr>
                             
      </table>
                          
   	  </form>
                      
                      <br />      
                                <form action="" method="post"  name="productsform" id="productsform" autocomplete='off'  >            
     <table width="80%"  border="1"  cellpadding="5" cellspacing="0" align="center">
      <!--<tr >
                              
                              <td colspan="2" >&nbsp;</td>
                              <td colspan="3" ><input name="txtserch" placeholder="Search by name " type="text" class="textbox" id="txtserch"  value="<?php echo $_POST['txtserch']?>"/></td>
                              <td colspan="2" ><input name="searchdata" type="submit" class="subm" id="searchdata" value="Search" /></td>
                              </tr>-->
<tr class="bg1">
                                        <td width="3%" height="28" align="center" ><span class="style1">SN</span></td>
                                        <td width="27%" align="left"><span class="style1">Company Name</span></td>
                                        <td width="8%" align="left" class="style1">Year</td>
                  <td width="5%" align="center" class="style1">Action</td>
       </tr>
                                      
                          <?php 
				
			/*	if($_REQUEST['brand']!='')
			 {
				 if($_REQUEST['brand']!='0')
				 {
				 $where= " where brand = '".$_REQUEST['brand']."' " ;
				 }
			 }
			 
			 	if(isset($_POST['searchdata']))
			 {
				 $where= " where name like  '%".$_POST['txtserch']."%' or pcode like  '%".$_POST['txtserch']."%'  " ;
			 }*/
			 
			 
						$serchqry="select * from admin_login $where ";
						$q=0;
						
							$qs=mysql_query($serchqry);
							while($row=mysql_fetch_array($qs))
							{
								$q=$q+1;
								/*if($row["pcode"]=='')
								{
									mysql_query("update product set pcode='P-".$row["id"]."' where id='".$row["id"]."' ");
								}*/
								?><tr>
                            <td align="center" ><?php echo $q ?></td>
                            <td align="left" ><?php echo $row["comp_name"]?></td>
                            <td align="left" ><?php echo $row["year"]?></td>
                            <td align="center" ><!--<a title="Delete Record" href="master_product.php?del=<?php //echo $row["id"];?>" onClick="return del();"><img src="images/del.png" /></a>-->&nbsp;<a title="Edit record" href="master_company.php?edit=<?php echo $row["id"];?>" ><img src="images/edit.png" /></a></td></tr><?php
				}
			
				
						?>
      </table>
                         	

                       
	  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
