<?php   include("../con_base/functions.inc.php"); if(isset($_GET['del']))
				{
						$arr=$_GET['del'];						
						mysql_query("delete from reg  where id='$arr'")or die(mysql_error());
						$sess_msg="Affiliates  Deleted Successfully";
						$_SESSION['sess_msg']=$sess_msg;
						header("Location: affliates_list");
						exit; 
				}
					if(isset($_GET['ban']))
					{
						mysql_query("update reg  set status=0 where id=".$_GET['ban']);
						$sess_msg="Affiliates Suspended Successfully";
						$_SESSION['sess_msg']=$sess_msg;
						header("Location: affliates_list");
						exit;
					}
					if(isset($_GET['unban']))
					{
						mysql_query("update reg set status=1 where id=".$_GET['unban']);
						$sess_msg="Affiliates Activated Successfully";
						$_SESSION['sess_msg']=$sess_msg;
						header("Location: affliates_list");
						exit;
					}?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Provider Management</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer">
 <div class="col-md-6 wow fadeInRight">
      <h1>Agent Register Free</h1>
      <p>Agent Signup</p>
      
     
      <div class="form-group">
        <label for="title">Name : </label>
        <input name="name" type="text" class="form-control input-sm" id="title" required>
      </div>
      <div class="form-group">
        <label for="mail">Email Id:</label>
        <input name="email" type="email" class="form-control input-sm" id="mail" required>
      </div>
      <div class="form-group">
        <label for="contact">Contact No. :</label>
        <input name="contact" type="number" required class="form-control input-sm" id="contact">
      </div>
      <div class="form-group">
        <label for="pass">Password:</label>
        <input name="pass" type="password" required class="form-control input-sm" id="pass">
      </div>
      <div class="form-group">
        <button class="btn btn-primary"  name="save" type="submit" style="font-size:24px;"> <span class="glyphicon fa fa-user-plus" ></span> Signup Request</button>
      </div>
     
    </div>
    
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
