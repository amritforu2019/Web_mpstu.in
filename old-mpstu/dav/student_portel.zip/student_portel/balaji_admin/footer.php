<div class="top" id="print">
  <div class="topleftm"> Copyright © <?php echo date('Y').'-'.(date('y')+1); ?> <?php echo $SITE_NAME;?> all right reserved </div>
  <div class="toprigtm"> Developed & Managed By <a style="color:#FFFFFF; text-decoration:none;" href="http://balajisoftwaresolution.com/" target="_blank">Balaji Software Solutions</a></div>
  <div class="c"></div>
</div>

<?php    ob_end_clean(); ob_end_flush(); ?>