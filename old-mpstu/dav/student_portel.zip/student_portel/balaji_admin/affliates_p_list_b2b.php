<?php   include("../con_base/functions.inc.php"); 
			if(isset($_GET['del']))
			{
			$arr=$_GET['del'];						
			mysql_query("delete from category_as where id ='$arr' ") ;
			$sess_msg="B2B Product Deleted Successfully";
			$_SESSION['sess_msg']=$sess_msg;
			header("Location: affliates_p_list_b2b");
			exit; 
			}
			if(isset($_GET['ban']))
			{
			mysql_query("update category_as  set status='0' where id=".$_GET['ban']);
			$sess_msg="B2B Product Suspended Successfully";
			$_SESSION['sess_msg']=$sess_msg;
			header("Location: affliates_p_list_b2b");
			exit;
			}
			if(isset($_GET['unban']))
			{
			mysql_query("update category_as set status='1' where id=".$_GET['unban']);
			$sess_msg="B2B Product Activated Successfully";
			$_SESSION['sess_msg']=$sess_msg;
			header("Location: affliates_p_list_b2b");
			exit;
			}
					?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Provider B2B Product Management</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer">
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" class="table">
      <tr>
        <td colspan="7" align="center" ><div align="center"><? echo  stripslashes($_SESSION['sess_msg']); unset($_SESSION['sess_msg']); unset($_SESSION['errorclass']);?></div></td>
      </tr>
      <tr   class="li">
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">SNo.</td>
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">Category</td>
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">Product Details</td>
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">Created By</td>
        <td align="left" valign="top"  bgcolor="#add8f8" class="heading">Reg date / By</td>
       <td align="center" valign="top"  bgcolor="#add8f8" class="heading">Action</td>
      </tr>
      <?   
				  
				  $q=mysql_query("select * from category_as   order by id desc"); 
				  $count=mysql_num_rows($q);
				  if($count!=0)
				  {
				  
				$i=1;
				while($row=mysql_fetch_array($q))
				{
				extract($row);
				 
$qry_p=mysql_query("select * from  reg where id='".$row['pr_id']."'")or die(mysql_error());  
$fetch_p=mysql_fetch_array($qry_p);

$qry_cat=mysql_query("select * from category where  id='".$row['parent_id']."'")or die(mysql_error());  
$fetch_cat=mysql_fetch_array($qry_cat);				  


if($row['area']=='')
{ 
mysql_query("update category_as set area='".$fetch_p['area']."' where id='".$row['id']."' ") ;
} 

if($row['state']=='')
{ 
mysql_query("update category_as set state='".$fetch_p['state']."' where id='".$row['id']."'");
}  

if($row['city']=='')
{ 
mysql_query("update category_as set city='".$fetch_p['city']."' where id='".$row['id']."' ") ;
}   
 
				 

?> 
				
				
				
				
      <tr bgcolor="#F2F2F2" class="textli">
        <td align="left" valign="top" bgcolor="#CCCDFD" class="bodytext"><? echo  $i;?></td>
        <td align="left" valign="top" bgcolor="#EDFEE7" class="bodytext"><strong><?php echo $fetch_cat['name'];?></strong>  </td>
        <td align="left" valign="top"  bgcolor="#FECAC7" class="bodytext"><?php echo $row['name'];?><br>MRP : <?php echo $row['mrp'];?><br>Qty : <?php echo $row['qty'];?><br>Rate : <?php echo $row['rate'];?><br></td>
        <td align="left" valign="top"  bgcolor="#FEFDD3" class="bodytext"><?php echo $fetch_p['contact_name'];?><br><?php echo $fetch_p['email'];?><br>
         <?php echo $fetch_p['contact'];?><br>
        <a href="#" title="<?php echo $fetch_p['addr'];?> Area : <?php echo $fetch_p['area_name'];?> <?php echo $fetch_p['city'];?> [<?php echo $fetch_p['state_name'];?>] Pin :<?php echo $fetch_p['pin'];?>">View Address</a></td>
        <td align="left" valign="top"  bgcolor="#CCCDFD" class="bodytext"><?php echo date("d-m-Y",strtotime($row['on_date']));?></td>
       <td align="center" valign="top"  bgcolor="#FECAC7" class="bodytext">  
         <a href="affliates_p_list_b2b?del=<?  echo  $id?>" onClick="return del();" title="Delete "><img src="images/del.png" alt="Delete " width="22" height="22" border="0"></a>
          <? if($row['status']=='0'){?>
          <a href="affliates_p_list_b2b?unban=<?  echo  $id?>" title="Activate " ><img src="images/not_verify.png" alt="Unban " width="16" height="16" border="0"></a>
          <? }
						  else { ?>
          <a href="affliates_p_list_b2b?ban=<?  echo  $id?>" title="Suspend " ><img src="images/pro-verified-ok.png" alt="Ban " width="14" height="14" border="0"></a>
          <? } ?></td>
      </tr>
      <?
					$i++;
				} 
				?>
      <? }   else { ?>
      <tr bgcolor="#F2F2F2" class="textli">
        <td colspan="6" align="center" bgcolor="#FFFFFF" class="bodytext"> Currently No Data Available</td>
      </tr>
      <? }   ?>
    </table>
    
 </form>
</div>
<?php include('footer.php');
mysql_query("ALTER TABLE `reg` ADD `doe` DATE NOT NULL ; ");
?>
</body>
</html>
<? ob_end_flush(); ?>
