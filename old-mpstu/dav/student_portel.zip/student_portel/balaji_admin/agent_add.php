<?php   include("../con_base/functions.inc.php"); 
if(isset($_POST['save']))
{


if(mysql_query("INSERT INTO `agent_reg` set `r_dt` =now() ,`r_typ`='".$_POST['r_typ']."' ,`name`='".$_POST['name']."' ,`email`='".$_POST['email']."' ,`contact`='".$_POST['contact']."' ,`pass`='".$_POST['pass']."' ,`reg_by`='admin'"))
{
?>
<script>alert('Agent Registration success'); location.href='agent_list';</script>
<?
}
else
{
?>
<script>alert('Agent Registration Error retry'); location.href='agent_list';</script>
<?
}

exit;
}?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Agent Register Free</h1>  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer">
    <table width="60%" border="1" align="center">
  <tr>
    <td><span class="form-group">Name :</span></td>
    <td><span class="form-group">
      <input name="name" type="text" class="textbox" id="title" required>
    </span></td>
    </tr>
  <tr>
    <td><span class="form-group">
    <label for="label">Email Id:</label>
    </span></td>
    <td><span class="form-group">
      <input name="email" type="email" class="textbox" id="mail" required>
    </span></td>
    </tr>
  <tr>
    <td><span class="form-group">
      <label for="label">Contact No. :</label>
    </span></td>
    <td><span class="form-group">
      <input name="contact" type="number" required class="textbox" id="contact">
    </span></td>
    </tr>
  <tr>
    <td><span class="form-group">Password:</span></td>
    <td><span class="form-group">
      <input name="pass" type="password" required class="textbox" id="pass">
    </span></td>
    </tr>
  <tr>
    <td colspan="2" align="center"> <button class="subm"  name="save" type="submit" > Signup Request</button></td>
    </tr>
</table>


    
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
