<?php   include("../con_base/functions.inc.php"); 
if(isset($_GET['del']))
{
$arr=$_GET['del'];						
mysql_query("delete from states_cities_area  where id='$arr'")or die(mysql_error());
$_SESSION['sess_msg']="Area  Deleted Successfully";
header("Location: area_list");
exit; 
}
if(isset($_GET['ban']))
{ 
mysql_query("update states_cities_area set flag=0 where  id=".$_GET['ban']);
$_SESSION['sess_msg']="Hide Successfully";
?>
<script>location.href="area_list?city_id=<?  echo $_GET['city_id']?>";</script>
<? exit;
}
if(isset($_GET['unban']))
{
mysql_query("update states_cities_area set flag=1 where  id=".$_GET['unban']);
$_SESSION['sess_msg']="Show Successfully";
?>
<script>location.href="area_list?city_id=<?  echo $_GET['city_id']?>";</script>
<? exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}

function load_page(val){    if(val!=0)  { location.href='area_list?state_id='+val;	return false; } }
function load_page2(val){	if(val!='') { location.href='area_list?city='+val;	return false; } }

</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add / Update Area &amp; Pincode</h1>
  <form name="form1" method="post" action="area_add" id="formID" class="formular validationEngineContainer">
    <table width="98%" border="0" align="center" cellpadding="5" cellspacing="0" >
      <tr>
        <td valign="top">
        <select name="state" id="state" class="textbox" onChange="return onchangeajax2(this.value);">
            <option value="0">--Search By State--</option>
            <?php 
$sql="SELECT * FROM   states order by state";
$result =mysql_query($sql);
 while($row=mysql_fetch_array($result)) { 

?>
            <option value="<?=$row['state_id']?>" <?php if($row['state_id']==$_REQUEST['state_id']){?>selected<?php }?>><?php echo $row['state'];?></option>
            <? } ?>
          </select>
          <script>
function onchangeajax2(pid2)
 {
 xmlHttp=GetXmlHttpObject()
 if (xmlHttp==null)
 {
 alert ("Browser does not support HTTP Request")
 return
 }

 var url1="ajax_city.php"
 url1=url1+"?pid2="+pid2
 url1=url1+"&sid1="+Math.random()
 document.getElementById("city_update").innerHTML="Searching cities please wait..."
 if(xmlHttp.onreadystatechange=stateChanged)
 {
 xmlHttp.open("GET",url1,true)
 xmlHttp.send(null)
 return true;
 }
 else
 {
 xmlHttp.open("GET",url1,true)
 xmlHttp.send(null)
 return false;
 }
 }

 function stateChanged()
 {
 if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
 {
 document.getElementById("city_update").innerHTML=xmlHttp.responseText
 return true;
 }
 }

function GetXmlHttpObject()
 {
 var objXMLHttp=null
 if (window.XMLHttpRequest)
 {
 objXMLHttp=new XMLHttpRequest()
 }
 else if (window.ActiveXObject)
 {
 objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP")
 }
 return objXMLHttp;
 }
 
 </script></td>
        <td valign="top">
<span id="city_update">
<select name="city" class="textbox" id="city"  >
<option value="">City</option>
<?php 
$sql="SELECT * FROM   states_cities where state_id='".$_REQUEST['state_id']."' order by city";
$result =mysql_query($sql);
 while($rowd=mysql_fetch_array($result)) { 

?>
<option value="<?=$rowd['city']?>" <?php if($rowd['city']==$_REQUEST['city_id']){?>selected<?php }?>><?php echo $rowd['city'];?></option>
<? } ?>
</select>
</span>
</td>
        <td valign="top"><input name="cityserch2" type="button" class="subm" onClick="load_page2(this.value)" value="Search"></td>
        <td valign="top"><input name="cityser" type="text" class="textbox" id="cityser" placeholder="Search by area Name / Pin code" value="<?=$_REQUEST['pin']?>" onClick="load_page2(cityser.value)" ></td>
        <td valign="top"><input name="cityserch" type="button" class="subm" onClick="load_page2(cityser.value)" value="Search"></td>
        <td valign="top"><input name="gone" type="submit" class="subm" id="gone2" value="Add New" ></td>
      </tr>
      <tr>
        <td colspan="6" align="center" valign="top"><? echo $_SESSION['sess_msg']; $_SESSION['sess_msg']=''; ?>
          <?
/*if(isset($_REQUEST['city']))
{
$df=trim($_REQUEST['city']);
$where="where city like '%$df%'";
} 
else if(isset($_REQUEST['state_id']))
{
$df=trim($_REQUEST['state_id']);
$where="where state_id ='$df'";
}	  
else
{
$where="";
}*/	
$start=0;
if(isset($_GET['start'])and $_GET['start']!='')$start=$_GET['start'];
$pagesize=50;
$state=$_REQUEST['state'];
$qry1=mysql_query("select * from states_cities_area $where")or die(mysql_error());
$qry=mysql_query("select * from states_cities_area $where order by area_name limit $start, $pagesize")or die(mysql_error());
$reccnt=mysql_num_rows($qry1);
$i=$start+1;
$k=$i;
echo  stripslashes($_SESSION['sess_msg']); unset($_SESSION['sess_msg']); ?></td>
      </tr>
      <tr>
        <td colspan="6" valign="top"><table width="95%" border="1" align="center" cellpadding="5" cellspacing="0" >
            <tr  >
              <td bgcolor="#add8f8" >SNo.</td>
              <td bgcolor="#add8f8" >Name</td>
              <td  bgcolor="#add8f8"  >City</td>
              <td  bgcolor="#add8f8"  >State</td>
              <td align="center" bgcolor="#add8f8"  >Action</td>
              <td bgcolor="#add8f8" >SNo.</td>
              <td bgcolor="#add8f8" >Name</td>
              <td  bgcolor="#add8f8"  >City</td>
              <td  bgcolor="#add8f8"  >State</td>
              <td align="center" bgcolor="#add8f8"  >Action</td>
            </tr>
            <tr >
              <?
while($row=mysql_fetch_array($qry)){ 
extract($row);
?>
              <td align="left" bgcolor="#FFFFFF" ><?  echo $i;?>
                .</td>
              <td bgcolor="#FFFFFF" ><? echo  normal_filter($area_name);?>/<? echo  normal_filter($pincode);?></td>
              <td  bgcolor="#FFFFFF" ><? echo  normal_filter($city_id);?></td>
              <td  bgcolor="#FFFFFF" ><? $sql2="SELECT * FROM   states where state_id='$state_id'";
$result2 =mysql_query($sql2);
$row2=mysql_fetch_array($result2); 
echo $row2['state']; ?></td>
              <td align="center"  bgcolor="#FFFFFF" ><a href="area_add?edit=<?  echo  $id?>" title="Edit "><img src="images/edit.png"  ></a> <a href="area_list?del=<?  echo  $id?>" onClick="return del();" title="Delete "><img src="images/del.png" ></a>
                <?  if($flag==0){?>
                <a href="area_list?unban=<?  echo $city_id?>&state_id=<?  echo $state_id?>" title="Enable" ><img src="images/not_verify.png" ></a>
                <? }  else { ?>
                <a href="area_list?ban=<?  echo $city_id?>&state_id=<?  echo $state_id?>" title="Disable" ><img src="images/pro-verified-ok.png" ></a>
                <? } ?></td>
              <? if($i%2==0) echo '</tr><tr>';  $i++;  }?>
            </tr>
          </table>
          <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center" ><?php include("../con_base/paging.inc.php"); ?></td>
            </tr>
          </table></td>
      </tr>
    </table>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
