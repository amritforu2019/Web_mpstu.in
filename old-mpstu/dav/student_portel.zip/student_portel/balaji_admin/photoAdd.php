<?php   include("../con_base/functions.inc.php"); master(); ?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>

<title><?php echo $ADMIN_HTML_TITLE;?></title>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add Images</h1>
  <form name="form1" method="post" action="" id="formID" enctype="multipart/form-data" class="formular validationEngineContainer">
 <?  

						  if(isset($_GET['edit']))

						  { 

							  $ty=$_GET['edit'];

							  $qry=mysql_query("select * from gal_img  where id='$ty' ")or die(mysql_error());

							  $row=mysql_fetch_array($qry);  

						  }  

						  if(isset($_POST['go']))

						  { 

								require_once("uploader4x.php"); 
								require("thumbcreatorx.php");  

							

								if($_FILES['uploaded_file_gallery']['name']!="")

									{

										upload_gallery();   

										cropImage(140, 140, '../upload/gallery/'.$finame_gallery, $bg_ext_gallery , '../upload/gallery/thumb/'.$finame_gallery);
										
										$where=" , images='$finame_gallery' " ; 

									}

								mysql_query("insert into gal_img set name='".$_POST['name']."', pid='".$_POST['pid']."',featured='".$_POST['featured']."' $where,status=1")or die(mysql_error()); 

								$sess_msg="Image Added Successfully";

								$_SESSION['sess_msg']=$sess_msg; 

								header("Location: photoGallery?pid=".$_POST['pid']); 
exit;
							} 
							
							
							
							if(isset($_POST['upd']))

						  { 

								require_once("uploader4x.php");   
require("thumbcreatorx.php");  
							

								if($_FILES['uploaded_file_gallery']['name']!="")

									{

										upload_gallery();   
cropImage(140, 140, '../upload/gallery/'.$finame_gallery, $bg_ext_gallery , '../upload/gallery/thumb/'.$finame_gallery);
										
										
										$where=" , images='$finame_gallery' " ; 

									}

								mysql_query("update gal_img set name='".$_POST['name']."' $where where id='".$_POST['edit']."'")or die(mysql_error()); 

								$sess_msg="Image Updated Successfully";

								$_SESSION['sess_msg']=$sess_msg; 

								header("Location: photoGallery?pid=".$_POST['pid2']); 
exit;
							}

			 	 		?>

                      <br> 

                    <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">  

					<? if($_SESSION['sess_msg']){?> 

<tr>

                          <td colspan="2" align="center" class="red">&nbsp;<? echo $_SESSION['sess_msg']; ?></td>
                        </tr>

						<? } ?>   

                        <tr>

                          <td height="22" align="right" valign="top"><strong>Upload Image :</strong></td>

                          <td valign="top">

                          <input name="uploaded_file_gallery" type="file" class="textbox" id="uploaded_file_gallery" size="30"><input name="edit" type="hidden" value="<? echo $_REQUEST['edit'];?>">
                          <input name="pid" type="hidden" value="<? echo $_REQUEST['pid'];?>">
                          
                           <input name="pid2" type="hidden" value="<? if(isset($_GET['edit'] )) echo stripslashes($row['pid']);?>">
                          
                          	</td>
                        </tr>  

						  

						<tr>
						  <td height="22" align="right">&nbsp;</td>
						  <td><span class="style1">Upload Image ( height  500px width auto according image) </span></td>
					  </tr>
						<tr>

                          <td height="22" align="right"> <strong> Title :</strong> </td>

                          <td><input name="name" type="text" class="textbox" id="name"  value="<? if(isset($_GET['edit'] )) echo stripslashes($row['name']); else echo stripslashes($name);?>"></td>
                        </tr>  

						

						<!--<tr>

                          <td height="22" align="right" valign="top"> <strong> Tagline :</strong> </td>

                          <td><input name="tagline" type="text" id="tagline" style="width:245px;"  value="<? if(isset($_GET['edit'] )) echo stripslashes($row['tagline']); else echo stripslashes($tagline);?>"> <br> 

                          <font style="font:10px arial; color:#ff0000;">for homepage flash</font></td>

                        </tr> 

						

						<tr>

                          <td height="22" align="right"> <strong> Featured :</strong> </td>

                          <td><input name="featured" type="checkbox" value="yes" <? if($_GET['edit'] and $row['featured']=='yes') echo 'checked'; elseif($featured=='yes') echo 'checked';?>></td>

                        </tr> -->  

						 

                        <tr>

                          <td width="30%" height="22">&nbsp;</td>

                          <td>

						  <input name="gone" type="button" class="subm" onClick="window.history.back()" value="Back">
<?php if($_REQUEST['edit']!='') { ?>
          <input name="upd" type="submit" class="subm" id="upd"  value="Update "/>
          <?php } else { ?>
					    <input name="go" type="submit" class="subm" id="go2" value="Add Image" > <? }  ?></td>
                        </tr> 
                    </table>

                 
 </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>