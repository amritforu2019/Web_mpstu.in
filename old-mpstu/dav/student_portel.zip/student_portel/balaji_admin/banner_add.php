<?php   include("../con_base/functions.inc.php");  master();?>
<?php
if(isset($_GET['edit']))
{
$ty=$_GET['edit'];
$qry=mysql_query("select * from flash_images where  id='$ty'")or die(mysql_error());
$row=mysql_fetch_array($qry)or die(mysql_error());
}


if(isset($_POST['go']))
{
$burl=mysql_real_escape_string($_POST['burl']);
$alttag=mysql_real_escape_string($_POST['alttag']);
require_once("uploader.php");
if(isset($_FILES['uploaded_file']))
{
upload("../upload/flash_images/");
if($finame!="")
{  
$q=mysql_query("insert into flash_images values(NULL, '".$_POST['type']."', '$finame', '$burl', '$alttag','".$_POST['content']."')") or die(mysql_error());
 $_SESSION['sess_msg']="<span style='color:red; font-size:14px;'>Image Added successfully</span>";
header("Location: banner_list");
}
}
exit;   
} 

if(isset($_POST['upd']))
{
$burl=mysql_real_escape_string($_POST['burl']);
$alttag=mysql_real_escape_string($_POST['alttag']);

if(isset($_FILES['uploaded_file']))
{
require_once("uploader.php");
upload("../upload/flash_images/");
if($finame!='')
{
$im=" , blocation= '$finame' ";
}
} 

mysql_query("update flash_images set burl='$burl',alttag='$alttag',dscr='".$_POST['content']."' $im where id='".$_POST['edit']."' ") or die(mysql_error());

 $_SESSION['sess_msg']="<span style='color:Green; font-size:14px;'>Image Updated successfully</span>";
header("Location: banner_list");


exit;   
} 
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Banner Add / Update</h1>
  <form action="banner_add.php" method="post" enctype="multipart/form-data" name="form1">
    <table width="70%" border="0" align="center" cellpadding="5" cellspacing="0">
      
      <tr>
        <td  colspan="2" ><?  echo $_SESSION['sess_msg']; unset($_SESSION['sess_msg']);?>          </td>
      </tr>
      <tr>
        <td width="24%" >
          <input name="type" type="hidden" value="1" />
          
          <input name="edit" type="hidden" value="<?=$_REQUEST['edit'];?>" />
          
         Upload Image :</td>
        <td width="76%"><input name="uploaded_file" type="file" class="textbox" id="uploaded_file" size="30" /></td>
      </tr>
     
      <tr>
        <td colspan="2" align="center" > Add 1000px <strong>X</strong> 300px for better view</td>
     </tr>
      <tr>
        <td  >Heading :          </td>
        <td><input name="burl" type="text" class="textbox" id="burl" value="<? if(isset($row['burl'])) echo $row['burl']; else echo $burl; ?>" size="40" /></td>
      </tr>
     
      <tr>
        <td  colspan="2" align="center"><textarea name="content" rows="10" style="width:100%"  ><?=stripslashes($row['dscr']);?></textarea>
          <?php /*?>id="content"<script type="text/javascript"> 

			CKEDITOR.replace( 'content',{

				toolbar :

						[

							

							

						

							{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },

							{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', ] },

							{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },

							{ name: 'colors', items : [ 'TextColor','BGColor' ]}, 

							

							'/',

							{ name: 'document', items : [ 'Source','-','Preview','Print','-'] },

							{ name: 'tools', items : [ 'Maximize'] },

							{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },

							{ name: 'editing', items : [ 'Find','Replace','-','SpellChecker'] }, 

							{ name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','SpecialChar' ] },

							{ name: 'links', items : [ 'Link','Unlink','Anchor' ] }  

							

						],

	filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

	filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

	filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

	filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

	filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

	filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

});



            </script><?php */?></td>
      </tr>
      <tr>
        <td  colspan="2" align="center">
        
        <?php if($_REQUEST['edit']!='') { ?>
          <input name="upd" type="submit" class="subm" id="upd"  value="Update "/>
          <?php } else { ?>
        <input name="go" type="submit" class="subm" id="go" value="Add Flash Image" onClick="return val();" />
        
        <? } ?>        </td>
      </tr>
    </table>
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>
