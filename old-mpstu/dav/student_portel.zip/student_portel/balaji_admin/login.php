<?php 
require_once "../con_base/functions.inc.php";
$tmpuserid=$_POST['loginid'];
$tmppassword=enc($_POST['password']);
$sql = "select * from admin_login where user='$tmpuserid' ";
//$ip=get_ip();
$result=mysql_query($sql);
$GetRows=mysql_num_rows($result);
if($GetRows>0)
{
$line=mysql_fetch_array($result);
if($line['pass']==$tmppassword)
{
	echo $userid=strtolower($tmpuserid);
	$sess_admin_id=strtolower($tmpuserid);
	$_SESSION['master']=$sess_admin_id;
	$_SESSION['master_main']=$sess_admin_id;
	$_SESSION['master_username']=$line['username'];	
	$_SESSION['master_davpgcvns']=$sess_admin_id;
	echo "<script>location='home.php';</script>";
	exit;
}
else
{
	$_SESSION['sess_msg']="Please Enter Valid Username/Password";
	echo "<script>location='index.php';</script>";
	exit();
}
}
else
{
	$_SESSION['sess_msg']="Please Enter Valid Username/Password";
	echo "<script>location='index.php';</script>";
	exit();
}

ob_end_flush();
?>