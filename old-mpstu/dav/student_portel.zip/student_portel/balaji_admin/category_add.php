<?php   include("../con_base/functions.inc.php"); 
if(isset($_GET['edit']))
 {
$ty=$_GET['edit'];
$qry=mysql_query("select * from category where id='$ty' ")or die(mysql_error());
 $row=mysql_fetch_array($qry);
 }
if(isset($_POST['go']))
{
require_once("uploader.php"); 
if(isset($_FILES['uploaded_file']))
{
upload("../upload/category/");
}
mysql_query("insert into category set parent_id='".$_POST['country']."', name='".$_POST['name']."', weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."' , imname='$finame', show_on='".$_POST['show_on']."',  status=0 , descr='".$_POST['descr']."',on_dt='".date("Y-m-d")."'")or die(mysql_error());

$catid=mysql_insert_id();

$i=0;
 
while($i < count($_POST['dur']))
{
if($_POST['dur'][$i]!="")
{
 
 $_POST['dur'][$i];
 
 mysql_query("insert into package set  title='".$_POST['dur'][$i]." Days', posted_on=now(),  descr='".$_POST['amt'][$i]."',  status=1 ,days='".$_POST['dur'][$i]."',category='".$catid."',category_main='".$_POST['country']."'")or die(mysql_error());
 
}
$i=$i+1;
}


$_SESSION['sess_msg']="Category Add Successfully";
 header("Location:category_list?parent=".$_POST['country']);
exit;
}
  if(isset($_POST['go2']))
{


$i=0;
 
while($i < count($_POST['dur']))
{
if($_POST['dur'][$i]!="")
{
 
  $q=mysql_query("select * from package  where category='".$_POST['edit']."' and id='".$_POST['piid'][$i]."'  "); 
$count=mysql_num_rows($q);
if($count>0)
{
 $rowgg=mysql_fetch_array($q);
   
 mysql_query("update package set  title='".$_POST['dur'][$i]." Days',  descr='".$_POST['amt'][$i]."',   days='".$_POST['dur'][$i]."' where  category='".$_POST['edit']."' and id='".$_POST['piid'][$i]."'  ")or die(mysql_error());
}
else
{
  
  
 mysql_query("insert into package set  title='".$_POST['dur'][$i]." Days', posted_on=now(),  descr='".$_POST['amt'][$i]."',  status=1 ,days='".$_POST['dur'][$i]."',category='".$_POST['edit']."',category_main='".$_POST['country']."'")or die(mysql_error());
 }
}
$i=$i+1;
}




require_once("uploader.php");
if(isset($_FILES['uploaded_file']))
 { upload("../upload/category/");  if($finame!="") { 
 $rw=mysql_query("select * from category where id='".$_POST['edit']."'");
 $rw1=mysql_fetch_array($rw)or die(mysql_error());
 $x=$rw1['imname'];
 unlink("../upload/category/".$x);
 
  // "update category set parent_id='".$_POST['country']."', name='".$_POST['name']."' , weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."' ,  imname='$finame', show_on='".$_POST['show_on']."' , descr='".$_POST['descr']."' , amt12='".$_POST['amt12']."' , amt3='".$_POST['amt3']."' , amt6='".$_POST['amt6']."' where id='".$_POST['edit']."'";
 
   
 $q=mysql_query("update category set parent_id='".$_POST['country']."', name='".$_POST['name']."' , weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."' ,  imname='$finame', show_on='".$_POST['show_on']."' , descr='".$_POST['descr']."',on_dt='".date("Y-m-d")."'   where id='".$_POST['edit']."'")or die(mysql_error());
 header("Location: category_list?parent=".$_POST['country']); exit;
 } else {
 $q=mysql_query("update category set parent_id='".$_POST['country']."', name='".$_POST['name']."' , weight='".$_POST['weight']."', pile_height='".$_POST['pile_height']."'  ,  show_on='".$_POST['show_on']."' , descr='".$_POST['descr']."',on_dt='".date("Y-m-d")."'  where id='".$_POST['edit']."'")or die(mysql_error());
 $_SESSION['sess_msg']="Category Updated Successfully";
 header("Location: category_list?parent=".$_POST['country']); exit ;
		} } }
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<style type="text/css">
.tetbx {
    margin-bottom: 5px;
    background: #FFF;
    color: #000000;
    font-size: 14px;
    border: 1px solid #CCC;
    padding: 5px;
    border-radius: 2px;
    width: 45%;
	}
</style>
<title><?php echo $ADMIN_HTML_TITLE;?></title>
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Add / Update Menu Category</h1>
  <form name="form1" method="post" action="" id="formID" class="formular validationEngineContainer" enctype="multipart/form-data">
    <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td width="36%" bgcolor="#D7D5FF" >Select Top  : </td>
   <td width="64%" bgcolor="#D7D5FF" ><select name="country" class="textbox"  >
            <option value="0" <? if($_REQUEST['country']==0 || $row['parent_id']==0) echo "selected";?>>Top</option>
<? $country_qry=mysql_query("select * from category where parent_id=0 order by name asc")or die(mysql_error());
 while($country_fetch=mysql_fetch_array($country_qry)) { ?>
            <option value="<? echo $country_fetch['id']?>" <? if($_REQUEST['parent']==$country_fetch['id'] || $row['parent_id']==$country_fetch['id']) echo "selected";?>><? echo normalall_filter($country_fetch['name'])?></option>
<?  $country_qry1=mysql_query("select * from category where parent_id='".$country_fetch['id']."' order by name asc")or die(mysql_error()); while($country_fetch1=mysql_fetch_array($country_qry1)) { ?>
            <option value="<? echo $country_fetch1['id']?>" <? if($_REQUEST['parent']==$country_fetch1['id'] || $row['parent_id']==$country_fetch1['id']) echo "selected";?>>&nbsp;&nbsp;&nbsp;--<? echo normalall_filter($country_fetch1['name'])?></option>
            <?  $country_qry2=mysql_query("select * from category where parent_id='".$country_fetch1['id']."' order by name asc")or die(mysql_error()); while($country_fetch2=mysql_fetch_array($country_qry2)) { ?>
            <option value="<? echo $country_fetch2['id']?>" <? if($_REQUEST['parent']==$country_fetch2['id'] || $row['parent_id']==$country_fetch2['id']) echo "selected";?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--<? echo normalall_filter($country_fetch2['name'])?></option>
            <? } } } ?>
          </select></td>
      </tr>
      <tr>
        <td bgcolor="#D7D5FF" >
            Name  :          
       <input name="weight" type="hidden"  id="cname2" size="50" value="<? if(isset($_GET['edit'] )) echo $row['weight'];  else echo stripslashes($_POST['weight'])	;?>" />           </td>
       <td bgcolor="#D7D5FF"><input name="name" type="text" class="textbox validate[required] text-input"  id="cname3" value="<? if(isset($_GET['edit'] )) echo $row['name'];  else echo stripslashes($_POST['name'])	;?>" size="50" /></td>
      </tr>

 
      <tr>
       <td colspan="2" align="center" valign="top" bgcolor="#D7D5FF" >Some Details : </td>
      </tr>
     <tr>
        <td colspan="2" valign="top" bgcolor="#D7D5FF" > <textarea name="pile_height" rows="6" class="textbox " id="cname"><? if(isset($_GET['edit'] )) echo $row['pile_height'];  else echo stripslashes($_POST['pile_height'])	;?></textarea>
        
        <script type="text/javascript"> 

			CKEDITOR.replace( 'cname',{

				toolbar :

						[

							

							

						

							{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },

							{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', ] },

							{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },

							{ name: 'colors', items : [ 'TextColor','BGColor' ]}, 

							

							'/',

							{ name: 'document', items : [ 'Source','-','Preview','Print','-'] },

							{ name: 'tools', items : [ 'Maximize'] },

							{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },

							{ name: 'editing', items : [ 'Find','Replace','-','SpellChecker'] }, 

							{ name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','SpecialChar' ] },

							{ name: 'links', items : [ 'Link','Unlink','Anchor' ] }  

							

						],

	filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

	filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

	filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

	filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

	filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

	filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

});



            </script>        </td>
      </tr>


      
      <tr>
       <td height="22" bgcolor="#D7D5FF" >Upload Image : </td>
       <td bgcolor="#D7D5FF"><input name="uploaded_file" type="file" class="textbox "  id="uploaded_file" /></td>
      </tr>
     
     
    <!--  <tr>
       <td height="22" colspan="2" align="center">Package payment Details</td>
      </tr>
      <tr>
       <td height="22" align="left" bgcolor="#C5FBFE">Qty Amt Amt</td>
       <td height="22" align="left" bgcolor="#C5FBFE"><input name="amt3" type="text" class="textbox " id="amt3" value="<? if(isset($_GET['edit'] )) echo $row['amt3'];  else echo stripslashes($_POST['amt3'])	;?>"></td>
      </tr>
      <tr>
       <td height="22" align="left" bgcolor="#C5FBFE">Half Year Amt</td>
       <td height="22" align="left" bgcolor="#C5FBFE"><input name="amt6" type="text" class="textbox " id="amt6" value="<? if(isset($_GET['edit'] )) echo $row['amt6'];  else echo stripslashes($_POST['amt6'])	;?>"></td>
      </tr>
      <tr>
       <td height="22" align="left" bgcolor="#C5FBFE">One Year Amt</td>
       <td height="22" align="left" bgcolor="#C5FBFE"><input name="amt12" type="text" class="textbox " id="amt12" value="<? if(isset($_GET['edit'] )) echo $row['amt12'];  else echo stripslashes($_POST['amt12'])	;?>"></td>
      </tr>-->
      <tr>
        <td height="22" colspan="2" align="center"><?php if($_REQUEST['edit']!='') { ?>
          <input name="edit" type="hidden" id="edit" value="<?php echo $_REQUEST['edit'];?>" />
          <input name="go2" type="submit" class="subm" id="go2" value="Update " />
          <? }  else  { ?>
          <input name="go" type="submit" class="subm" id="go" value="Add " />
          <? } ?>        </td>
      </tr>
    </table>
   <p>&nbsp;</p>
   
 
   
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<script>
    $(document).ready(function() {

        var iCnt = 0;
        // CREATE A "DIV" ELEMENT AND DESIGN IT USING JQUERY ".css()" CLASS.
        var container = $(document.createElement('div')).css({
            padding: '5px', margin: '20px', width: '500px', border: '1px dashed',
            borderTopColor: '#999', borderBottomColor: '#999',
            borderLeftColor: '#999', borderRightColor: '#999'
        });

        $('#btAdd').click(function() {
            if (iCnt <= 19) {

                iCnt = iCnt + 1;

                // ADD TEXTBOX.
                $(container).append('  <input placeholder="Enter Duration Amount" type=number class="tetbx" id="amt' + iCnt+'"   name="amt[]"   value=" " />&nbsp; <input type=number required class="tetbx" id="dur' + iCnt+'"   name="dur[]"  required  placeholder="Enter Duration In Days"/> </br>  ');

                // SHOW SUBMIT BUTTON IF ATLEAST "1" ELEMENT HAS BEEN CREATED.
                if (iCnt == 1) {

                    var divSubmit = $(document.createElement('div'));
                    $(divSubmit).append(' ');

                }

                // ADD BOTH THE DIV ELEMENTS TO THE "main" CONTAINER.
                $('#main').after(container, divSubmit);
            }
            // AFTER REACHING THE SPECIFIED LIMIT, DISABLE THE "ADD" BUTTON.
            // (20 IS THE LIMIT WE HAVE SET)
            else {      
                $(container).append('<label>Reached the limit</label>'); 
                $('#btAdd').attr('class', 'bt-disable'); 
                $('#btAdd').attr('disabled', 'disabled');
            }
        });

        // REMOVE ELEMENTS ONE PER CLICK.
        $('#btRemove').click(function() {
            if (iCnt != 0) { $('#amt' + iCnt).remove(); $('#dur' + iCnt).remove(); iCnt = iCnt - 1; }
        
            if (iCnt == 0) { 
                $(container)
                    .empty() 
                    .remove(); 

                $('#btSubmit').remove(); 
                $('#btAdd')
                    .removeAttr('disabled') 
                    .attr('class', 'subm') 

            }
        });

        // REMOVE ALL THE ELEMENTS IN THE CONTAINER.
        $('#btRemoveAll').click(function() {
            $(container)
                .empty()
                .remove(); 

            $('#btSubmit').remove(); 
            iCnt = 0; 
            
            $('#btAdd')
                .removeAttr('disabled') 
                .attr('class', 'bt');
        });
    });

    // PICK THE VALUES FROM EACH TEXTBOX WHEN "SUBMIT" BUTTON IS CLICKED.
    var divValue, values = '';

    function GetTextValue() {

        $(divValue) 
            .empty() 
            .remove(); 
        
        values = '';

        $('.input').each(function() {
            divValue = $(document.createElement('div')).css({
                padding:'5px', width:'200px'
            });
            values += this.value + '<br />'
        });

        $(divValue).append('<p><b>Your selected values</b></p>' + values);
        $('body').append(divValue);
    }
</script>
<? ob_end_flush(); ?>
