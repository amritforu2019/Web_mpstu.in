<?php   include("../con_base/functions.inc.php"); master(); ?>


 
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>

<title><?php echo $ADMIN_HTML_TITLE;?></title>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Category Slider Gallery</h1>
  <form name="form1" method="post" action="photoAdd2?pid=<? echo $_GET['pid'];?>" id="formID" class="formular validationEngineContainer">
<table width="100%" > 

                <tr>

                  <td valign="top" >

				  <? 


					  if(isset($_GET['unfeatured']))

						{

							$re=mysql_fetch_array(mysql_query("select images from gal_img2 where id='".$_GET['unfeatured']."'")); 

							@unlink("../upload/gallery/homepage/".$re['images']); 

							mysql_query("update gal_img2  set featured='no' where id=".$_GET['unfeatured']);
							$_SESSION['sess_msg']='<div align=center class=correct>Image Un Featured successfully....</div>';

							header("Location: photoGallery2?start=".$_REQUEST['start']."&pid=".$_REQUEST['pid']);		

							exit;

						}

						

						if(isset($_GET['featured']))

						{

							$re=mysql_fetch_array(mysql_query("select images from gal_img2 where id='".$_GET['featured']."'")); 

							require("thumbcreator.php"); 

							list ($name, $ext) = explode (".", $re['images']); 

							$bg_ext_gallery=$ext;

							cropImage(684, 381, '../upload/gallery/'.$re['images'], $bg_ext_gallery , '../upload/gallery/homepage/'.$re['images']); 

							mysql_query("update gal_img  set featured='yes' where id=".$_GET['featured']);
							$_SESSION['sess_msg']='<div align=center class=correct>Image Featured successfully....</div>';

							header("Location: photoGallery2?start=".$_REQUEST['start']."&pid=".$_REQUEST['pid']);		

							exit;

						}

						

					 if(isset($_GET['dele']))

						{ 

							$re=mysql_fetch_array(mysql_query("select images from gal_img2 where id='".$_GET['dele']."'")); 

							@unlink("../upload/gallery/".$re['images']); 

							@unlink("../upload/gallery/thumb/".$re['images']);

							@unlink("../upload/gallery/homepage/".$re['images']); 

							mysql_query("delete from gal_img2 where id='".$_GET['dele']."'")or die(mysql_error()); 

							$_SESSION['sess_msg']='<div align=center class=correct>Image deleted successfully....</div>'; 

							header("Location: photoGallery2?start=".$_REQUEST['start']."&pid=".$_REQUEST['pid']);		

							exit; 

					 }

					 if(isset($_GET['ban']))

						{

							mysql_query("update gal_img2  set status=0 where id=".$_GET['ban']);

							$_SESSION['sess_msg']='<div align=center class=correct>Image Deactivated successfully....</div>';

							header("Location: photoGallery2?start=".$_REQUEST['start']."&pid=".$_REQUEST['pid']);		

							exit;

						}

					if(isset($_GET['unban']))

						{

							mysql_query("update gal_img2  set status=1 where id=".$_GET['unban']);

							$_SESSION['sess_msg']='<div align=center class=correct>Image Activated successfully....</div>';

							header("Location: photoGallery2?start=".$_REQUEST['start']."&pid=".$_REQUEST['pid']);		

							exit;

						} 

					$start=0;

					if(isset($_GET['start'])and $_GET['start']!='')$start=$_GET['start'];

					$pagesize=15; 

					$qry1=mysql_query("select *  from gal_img2 where pid='".$_REQUEST['pid']."'")or die(mysql_error());

					$qry=mysql_query("select * from gal_img2 where pid='".$_REQUEST['pid']."' order by id DESC limit $start, $pagesize")or die(mysql_error()); 

					$reccnt=mysql_num_rows($qry1);  

									

				?> 	

                      <table width="80%" border="0" align="center" cellpadding="5" cellspacing="0">

                        <tr >

                            

                          <td  valign="top" > </td>

                          <td align="right" > 

						  
					    <input name="gone" type="submit" class="subm" id="gone" value="Add Image" /></td>

                        </tr>

						<? if($reccnt!=0){?>

                        <tr >

                          <td  colspan="3" align="center" > </td>

                        </tr>

						<tr>

						 <td colspan="3" align="center" >

						 <table width="100%" border="0" cellpadding="10" cellspacing="0">

						  <tr>

						  <? $i=$start+1; $k=$i; while($row=mysql_fetch_array($qry)){ extract($row);?> 

							<td align="center"> 

						 	<table border="0" cellspacing="0" cellpadding="0">

                            <tr>

                              <td align="center" valign="top"><!--<? if($featured=='yes'){?>

                                <a href="photoGallery?unfeatured=<? echo $id?>&start=<? echo $_REQUEST['start'] ?>&pid=<? echo $_REQUEST['pid'] ?>"  title="Featured Category"><img src="images/featured.gif" alt="Featured" width="22" height="22"  border="0" ></a>

                                <? } if($row['pname']==''){ 
				$country_qry=mysql_query("select * from category where id='".$row['pid']."'")or die(mysql_error());  
				$country_fetch=mysql_fetch_array($country_qry);
				  
				mysql_query("update gal_img2 set pname='".$country_fetch['name']."'  where id='".$row['id']."'  ") ;
				}  ?>--></td>

                              <td align="center" valign="top">

                                <a href="../upload/gallery/<? echo $row['images']; ?>" target="_blank"> <img src="../upload/gallery/<? echo $row['images']; ?>" alt="<? echo $row['name'];?>" height="200" align="top" style="border:#000000 solid 1px;" /></a><br />
<strong><? echo strip_filter($row['name'],25);?></strong></td>

                            </tr>

                            <tr>

                              <td  colspan="2" align="center">
							  <!--<a href="photoadd1?edit=<?  echo $id?>&pid=<? echo $_REQUEST['pid'] ?>" title="Edit images"><img src="images/but_edit_small.gif" alt="Edit Photo Gallery Category" width="22" height="22" border="0"></a>-->

							 <?php /*?> <? if($featured=='no'){?>

							  <a href="photoGallery?featured=<? echo $id?>&start=<? echo $_REQUEST['start'] ?>&pid=<? echo $_REQUEST['pid'] ?>"  title="Featured Category"><img src="images/featured.gif" alt="Featured" width="22" height="22"  border="0"></a>

							  <? } ?><?php */?>
<a href="photoAdd2?edit=<? echo $id?>&start=<? echo $_REQUEST['start'] ?>"  title="Edit Image"><img src="images/edit.png" alt="Featured" width="20" height="20"  border="0" /></a>
							  <a href="photoGallery2?dele=<?  echo $id?>&start=<? echo $_REQUEST['start'] ?>&pid=<? echo $_REQUEST['pid'] ?>" onClick="return del();" title="Delete Category"><img src="images/del.png" alt="Delete Category" width="22" height="22" border="0" /></a>
                              
                               

                               <?php /*?> <? if($status==0){?>

                                <a href="photoGallery?unban=<?  echo $id?>&start=<? echo $_REQUEST['start'] ?>&pid=<? echo $_REQUEST['pid'] ?>" title="Unban Category" ><img src="images/but_unban_small.gif" alt="Unban Category" width="22" height="22" border="0"></a>

                                <? }

						  else { ?>

                                <a href="photoGallery?ban=<? echo $id?>&start=<? echo $_REQUEST['start'] ?>&pid=<? echo $_REQUEST['pid'] ?>" title="Ban Category"><img src="images/but_ban_small.gif" alt="Ban Category" width="22" height="22" border="0"></a>

                                <? } ?><?php */?></td>

                            </tr>

                          </table>							</td>

						    <? if($k%2==0) echo "</tr><tr>"; ?>

							<? $i++; $k++;}}?>

						  </tr>

						</table> <br /> 

						<table width="98%" border="0" align="center" cellpadding="5" cellspacing="0">

                        <tr>

                          <td align="center" ><? if($reccnt==0) { ?><span class="red">No Image Available...<a href="photoAdd2?yahoo=sf&pid=<? echo $_GET['pid'];?>" class="boldlisting">Add First</a></span> <? } ?></td>

                        </tr>

                    </table>						</td></tr>

                    </table> 

                    <table width="80%" border="0" align="center" cellpadding="2" cellspacing="5">

                        <tr>

                          <td align="center" ><?php include("../con_base/paging.inc.php"); ?>

                          </td>

                        </tr>

                  </table></td>

                </tr>

          </table> </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>