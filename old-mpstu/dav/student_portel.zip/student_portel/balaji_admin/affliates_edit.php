<?php   include("../con_base/functions.inc.php"); 

if(isset($_POST["upd"]))
{

  $partyqry="update  `reg` set   `name` ='".$_POST["name"]."',`contact`='".$_POST["contact"]."' ,`acname`='".$_POST["acname"]."' ,`bankname`='".$_POST["bankname"]."' ,`acno`='".$_POST["acno"]."' ,`ifsc`='".$_POST["ifsc"]."' ,`brname`='".$_POST["brname"]."', contact2 ='".$_POST['contact2']."'   where `id`='".$_POST['edit']."'";

if(mysql_query($partyqry))
{
$_SESSION['msg']="<span style='color:green; font-size:14px;'>Record Updated Successfully</span>";
	?>
<script>
alert("Updated Successfully");
location.href="affliates_list";
</script>
<?php
}
exit;
}







	$serchqry="select * from reg where id='".$_REQUEST['edit']."' ";
	$qs=mysql_query($serchqry);
	$editrow=mysql_fetch_array($qs);
	

?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>

<title><?php echo $ADMIN_HTML_TITLE;?></title>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Service Provider Profile Update</h1>
 <form action="" method="post" name="search_frm" id="formID" class="formular validationEngineContainer" enctype="multipart/form-data">
 <table width="60%" border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td width="35%" bgcolor="#E3FFDD"><span class="form-group">Name :</span></td>
    <td width="65%" bgcolor="#E3FFDD"><span class="form-group"><input name="edit" type="hidden" value="<?php echo $_REQUEST['edit'] ?>">
      <input name="name" type="text" class="textbox" id="title" value="<?php echo ($editrow['name']); ?>" required>
    </span></td>
    </tr>
  <tr>
    <td bgcolor="#E3FFDD"><span class="form-group">
      <label for="label">Email Id :</label>
    </span></td>
    <td bgcolor="#E3FFDD"><span class="form-group">
      <input name="email" type="text" class="textbox" id="mail" value="<?php echo ($editrow['email']); ?>" readonly>
    </span></td>
    </tr>
  <tr>
    <td bgcolor="#E3FFDD"><span class="form-group">
      <label for="label">Contact No. :</label>
    </span></td>
    <td bgcolor="#E3FFDD"><span class="form-group">
      <input name="contact" type="number" class="textbox" id="contact" value="<?php echo ($editrow['contact']); ?>" required>
    </span></td>
    </tr>
    
  <tr>
    <td bgcolor="#E3FFDD">Contact No 2 : </td>
    <td bgcolor="#E3FFDD"><span class="form-group">
      <input name="contact2" type="number" value="<?php echo ($editrow['contact2']); ?>" required class="textbox validate[required] text-input" id="contact2">
    </span></td>
  </tr>
    
  <tr>
    <td colspan="2" bgcolor="#D9E6FD">Bank Account Details :</td>
    </tr>
  <tr>
    <td bgcolor="#D9E6FD">Account Name :</td>
    <td bgcolor="#D9E6FD"><input name="acname"   type="text"  value="<?php echo ($editrow['acname']); ?>" class="textbox" id="acname" /></td>
  </tr>
  <tr>
    <td bgcolor="#D9E6FD">Bank Name :</td>
    <td bgcolor="#D9E6FD"><input name="bankname"   type="text"  value="<?php echo ($editrow['bankname']); ?>" class="textbox" id="bankname" /></td>
    </tr>
  <tr>
    <td bgcolor="#D9E6FD">Account No. :</td>
    <td bgcolor="#D9E6FD"><input name="acno"   type="text"  value="<?php echo ($editrow['acno']); ?>" class="textbox" id="acno" /></td>
  </tr>
  <tr>
    <td bgcolor="#D9E6FD">IFSC Code :</td>
    <td bgcolor="#D9E6FD"><input name="ifsc"   type="text"  value="<?php echo ($editrow['ifsc']); ?>" class="textbox" id="ifsc" /></td>
  </tr>
  <tr>
    <td bgcolor="#D9E6FD">Branch Name :</td>
    <td bgcolor="#D9E6FD"><input name="brname"   type="text"  value="<?php echo ($editrow['brname']); ?>" class="textbox" id="brname" /></td>
    </tr>
  <tr>
    <td colspan="2" align="center"><label>
       <input name="upd" type="submit" class="subm" id="upd"  value="Update : <?php echo $editrow['name']; ?>"/>
    </label></td>
    </tr>
</table>
 
    
  </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>