<?php   include("../con_base/functions.inc.php"); ?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>

<title><?php echo $ADMIN_HTML_TITLE;?></title>

<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine();
			$(".submit").click(function(){
				jQuery("#formID").validationEngine('validate');
			})
		});

		
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
</head>
<body>
<?php include('header.php');?>
<div class="conten">
  <h1>Manage Flash Images</h1>
  <form name="form1" method="post" action="photoGallery_cat_add" id="formID" class="formular validationEngineContainer">


				  <?  

					  if(isset($_GET['edit']))

					  { 

						  $ty=$_GET['edit'];

						  $qry=mysql_query("select * from photogallery_cat  where id='$ty' ")or die(mysql_error());

						  $row=mysql_fetch_array($qry);

						  $_SESSION['cap_use']=$row['name']; 

					  } 

					  if(isset($_POST['go']))

					  {

						  if($_POST['edit']!='') { 

								mysql_query("update photogallery_cat set name='".addslashes($_POST['name'])."' where id='".$_POST['edit']."'")or die(mysql_error());

								$sess_msg="Photo Gallery Category Updated Successfully";

								$_SESSION['sess_msg']=$sess_msg;

								header("Location: photoGallery_cat"); 

						 } 

						 else {   

								  mysql_query("insert into photogallery_cat set name='".addslashes($_POST['name'])."', status=1")or die(mysql_error());

								  $sess_msg="Photo Gallery Category Added Successfully";

								  $_SESSION['sess_msg']=$sess_msg;

								  header("Location: photoGallery_cat");

							 } 

						} 

					?> 

                <table width="300" border="0" align="center" cellpadding="2" cellspacing="4">   

                <tr>

                  <td height="22" align="right" nowrap class="hometext">Name :</td>

                  <td><input name="name" type="text" class="textbox validate[required] text-input" id="name" style="width:255px;" value="<? if(isset($_GET['edit'] )) echo stripslashes($row['name']); ?>">
                  <input name="edit" type="hidden" value="<? echo $_REQUEST['edit'];?>"></td>

                  <td align="left"><input name="go" type="submit" class="subm" id="go" value="<? if(isset($_SESSION['naukri'])) echo "Update"; else echo "Add"?> Category" onClick="return chk();"></td>

                </tr>

                </table> 

             
 </form>
</div>
<?php include('footer.php');?>
</body>
</html>
<? ob_end_flush(); ?>