<footer>
<p>Copyright &copy 2016-17 Dav PG College Varanasi. All Rights Reserved | Developed by <a href="http://balajisoftwaresolution.com/" target="_blank">Balaji Software Solution</a></p>
</footer>
