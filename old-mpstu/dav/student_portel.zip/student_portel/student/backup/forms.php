
<!DOCTYPE HTML>
<html>
<head>
<title>Look2Get  | Forms :: </title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="../css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="../css/font-awesome.css" rel="stylesheet" /> 
<!-- jQuery -->
<!-- lined-icons -->
<link rel="stylesheet" href="../css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<!-- chart -->
<script src="../js/Chart.js"></script>
<!-- //chart -->
<!--animate-->
<link href="../css/animate.css" rel="stylesheet" type="text/css" media="all" />
<script src="../js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!----webfonts--->
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css' />
<!---//webfonts---> 
 <!-- Meters graphs -->
<script src="../js/jquery-1.10.2.min.js"></script>
<!-- Placed js at the end of the document so the pages load faster -->

</head> 
   
 <body class="sticky-header left-side-collapsed"  onload="initMap()">
    <section>
    <!-- left side start-->
		<div class="left-side sticky-left-side">

			<!--logo and iconic logo start-->
			<div class="logo">
				<h1><a href="../index.html">Easy <span>Admin</span></a></h1>
			</div>
			<div class="logo-icon text-center">
				<a href="../index.html"><i class="lnr lnr-home"></i> </a>
			</div>

			<!--logo and iconic logo end-->
			<div class="left-side-inner">

				<!--sidebar nav start-->
					<ul class="nav nav-pills nav-stacked custom-nav">
						<li><a href="../index.html"><i class="lnr lnr-power-switch"></i><span>Dashboard</span></a></li>
						<li class="menu-list">
							<a href="../#"><i class="lnr lnr-cog"></i>
								<span>Components</span></a>
								<ul class="sub-menu-list">
									<li><a href="../grids.html">Grids</a> </li>
									<li><a href="../widgets.html">Widgets</a></li>
								</ul>
						</li>
						<li class="active"><a href="../forms.html"><i class="lnr lnr-spell-check"></i> <span>Forms</span></a></li>
						<li><a href="../tables.html"><i class="lnr lnr-menu"></i> <span>Tables</span></a></li>              
						<li class="menu-list"><a href="../#"><i class="lnr lnr-envelope"></i> <span>MailBox</span></a>
							<ul class="sub-menu-list">
								<li><a href="../inbox.html">Inbox</a> </li>
								<li><a href="../compose-mail.html">Compose Mail</a></li>
							</ul>
						</li>  
						<li class="menu-list"><a href="../#"><i class="lnr lnr-indent-increase"></i> <span>Menu Levels</span></a>  
							<ul class="sub-menu-list">
								<li><a href="../charts.html">Basic Charts</a> </li>
							</ul>
						</li>
						<li><a href="../codes.html"><i class="lnr lnr-pencil"></i> <span>Typography</span></a></li>
						<li><a href="../media.html"><i class="lnr lnr-select"></i> <span>Media Css</span></a></li>
						<li class="menu-list"><a href="../#"><i class="lnr lnr-book"></i>  <span>Pages</span></a> 
							<ul class="sub-menu-list">
								<li><a href="../sign-in.html">Sign In</a> </li>
								<li><a href="../sign-up.html">Sign Up</a></li>
								<li><a href="../blank_page.html">Blank Page</a></li>
							</ul>
						</li>
					</ul>
				<!--sidebar nav end-->
			</div>
		</div>
    <!-- left side end-->
    
    <!-- main content start-->
		<div class="main-content main-content3">
			<!-- header-starts -->
			<div class="header-section">
			 
			<!--toggle button start-->
			<a class="toggle-btn  menu-collapsed"><i class="fa fa-bars"></i></a>
			<!--toggle button end-->

			<!--notification menu start -->
			<div class="menu-right">
				<div class="user-panel-top">  	
					<div class="profile_details_left">
						<ul class="nofitications-dropdown">
							<li class="dropdown">
								<a href="../#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-envelope"></i><span class="badge">3</span></a>
									
										<ul class="dropdown-menu">
											<li>
												<div class="notification_header">
													<h3>You have 3 new messages</h3>
												</div>
											</li>
											<li><a href="../#">
											   <div class="user_img"><img src="../images/1.png" alt="" /></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor sit amet</p>
												<p><span>1 hour ago</span></p>
												</div>
											   <div class="clearfix"></div>	
											 </a></li>
											 <li class="odd"><a href="../#">
												<div class="user_img"><img src="../images/1.png" alt="" /></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor sit amet </p>
												<p><span>1 hour ago</span></p>
												</div>
											  <div class="clearfix"></div>	
											 </a></li>
											<li><a href="../#">
											   <div class="user_img"><img src="../images/1.png" alt="" /></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor sit amet </p>
												<p><span>1 hour ago</span></p>
												</div>
											   <div class="clearfix"></div>	
											</a></li>
											<li>
												<div class="notification_bottom">
													<a href="../#">See all messages</a>
												</div> 
											</li>
										</ul>
							</li>
							<li class="login_box" id="loginContainer">
									<div class="search-box">
										<div id="sb-search" class="sb-search">
											<form>
												<input class="sb-search-input" placeholder="Enter your search term..." type="search" id="search" />
												<input class="sb-search-submit" type="submit" value="" />
												<span class="sb-icon-search"> </span>
											</form>
										</div>
									</div>
										<!-- search-scripts -->
										<script src="../js/classie.js"></script>
										<script src="../js/uisearch.js"></script>
											<script>
												new UISearch( document.getElementById( 'sb-search' ) );
											</script>
										<!-- //search-scripts -->
							</li>
							<li class="dropdown">
								<a href="../#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">3</span></a>
									<ul class="dropdown-menu">
										<li>
											<div class="notification_header">
												<h3>You have 3 new notification</h3>
											</div>
										</li>
										<li><a href="../#">
											<div class="user_img"><img src="../images/1.png" alt="" /></div>
										   <div class="notification_desc">
											<p>Lorem ipsum dolor sit amet</p>
											<p><span>1 hour ago</span></p>
											</div>
										  <div class="clearfix"></div>	
										 </a></li>
										 <li class="odd"><a href="../#">
											<div class="user_img"><img src="../images/1.png" alt="" /></div>
										   <div class="notification_desc">
											<p>Lorem ipsum dolor sit amet </p>
											<p><span>1 hour ago</span></p>
											</div>
										   <div class="clearfix"></div>	
										 </a></li>
										 <li><a href="../#">
											<div class="user_img"><img src="../images/1.png" alt="" /></div>
										   <div class="notification_desc">
											<p>Lorem ipsum dolor sit amet </p>
											<p><span>1 hour ago</span></p>
											</div>
										   <div class="clearfix"></div>	
										 </a></li>
										 <li>
											<div class="notification_bottom">
												<a href="../#">See all notification</a>
											</div> 
										</li>
									</ul>
							</li>	
							<li class="dropdown">
								<a href="../#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-tasks"></i><span class="badge blue1">22</span></a>
									<ul class="dropdown-menu">
										<li>
											<div class="notification_header">
												<h3>You have 8 pending task</h3>
											</div>
										</li>
										<li><a href="../#">
												<div class="task-info">
												<span class="task-desc">Database update</span><span class="percentage">40%</span>
												<div class="clearfix"></div>	
											   </div>
												<div class="progress progress-striped active">
												 <div class="bar yellow" style="width:40%;"></div>
											</div>
										</a></li>
										<li><a href="../#">
											<div class="task-info">
												<span class="task-desc">Dashboard done</span><span class="percentage">90%</span>
											   <div class="clearfix"></div>	
											</div>
										   
											<div class="progress progress-striped active">
												 <div class="bar green" style="width:90%;"></div>
											</div>
										</a></li>
										<li><a href="../#">
											<div class="task-info">
												<span class="task-desc">Mobile App</span><span class="percentage">33%</span>
												<div class="clearfix"></div>	
											</div>
										   <div class="progress progress-striped active">
												 <div class="bar red" style="width: 33%;"></div>
											</div>
										</a></li>
										<li><a href="../#">
											<div class="task-info">
												<span class="task-desc">Issues fixed</span><span class="percentage">80%</span>
											   <div class="clearfix"></div>	
											</div>
											<div class="progress progress-striped active">
												 <div class="bar  blue" style="width: 80%;"></div>
											</div>
										</a></li>
										<li>
											<div class="notification_bottom">
												<a href="../#">See all pending task</a>
											</div> 
										</li>
									</ul>
							</li>		   							   		
							<div class="clearfix"></div>	
						</ul>
					</div>
					<div class="profile_details">		
						<ul>
							<li class="dropdown profile_details_drop">
								<a href="../#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
									<div class="profile_img">	
										<span style="background:url(images/1.jpg) no-repeat center"> </span> 
										 <div class="user-name">
											<p>Michael<span>Administrator</span></p>
										 </div>
										 <i class="lnr lnr-chevron-down"></i>
										 <i class="lnr lnr-chevron-up"></i>
										<div class="clearfix"></div>	
									</div>	
								</a>
								<ul class="dropdown-menu drp-mnu">
									<li> <a href="../#"><i class="fa fa-cog"></i> Settings</a> </li> 
									<li> <a href="../#"><i class="fa fa-user"></i>Profile</a> </li> 
									<li> <a href="../sign-up.html"><i class="fa fa-sign-out"></i> Logout</a> </li>
								</ul>
							</li>
							<div class="clearfix"> </div>
						</ul>
					</div>		
					<div class="social_icons">
						<div class="col-md-4 social_icons-left">
							<a href="../#" class="yui"><i class="fa fa-facebook i1"></i><span>300<sup>+</sup> Likes</span></a>
						</div>
						<div class="col-md-4 social_icons-left pinterest">
							<a href="../#"><i class="fa fa-google-plus i1"></i><span>500<sup>+</sup> Shares</span></a>
						</div>
						<div class="col-md-4 social_icons-left twi">
							<a href="../#"><i class="fa fa-twitter i1"></i><span>500<sup>+</sup> Tweets</span></a>
						</div>
						<div class="clearfix"> </div>
					</div>			             	
					<div class="clearfix"></div>
				</div>
			</div>
			<!--notification menu end -->
			</div>
	<!-- //header-ends -->
			<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Basic Forms</h3>
						<div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
							<form class="form-horizontal">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Focused Input</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="focusedinput" placeholder="Default Input" />
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block">Your help text!</p>
									</div>
								</div>
								<div class="form-group">
									<label for="disabledinput" class="col-sm-2 control-label">Disabled Input</label>
									<div class="col-sm-8">
										<input disabled="" type="text" class="form-control1" id="disabledinput" placeholder="Disabled Input" />
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Password</label>
									<div class="col-sm-8">
										<input type="password" class="form-control1" id="inputPassword" placeholder="Password" />
									</div>
								</div>
								<div class="form-group">
									<label for="checkbox" class="col-sm-2 control-label">Checkbox</label>
									<div class="col-sm-8">
										<div class="checkbox-inline1"><label><input type="checkbox" /> Unchecked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" checked="" /> Checked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" disabled="" /> Disabled Unchecked</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" disabled="" checked="" /> Disabled Checked</label></div>
									</div>
								</div>
								<div class="form-group">
									<label for="checkbox" class="col-sm-2 control-label">Checkbox Inline</label>
									<div class="col-sm-8">
										<div class="checkbox-inline"><label><input type="checkbox" /> Unchecked</label></div>
										<div class="checkbox-inline"><label><input type="checkbox" checked="" /> Checked</label></div>
										<div class="checkbox-inline"><label><input type="checkbox" disabled="" /> Disabled Unchecked</label></div>
										<div class="checkbox-inline"><label><input type="checkbox" disabled="" checked="" /> Disabled Checked</label></div>
									</div>
								</div>
								<div class="form-group">
									<label for="selector1" class="col-sm-2 control-label">Dropdown Select</label>
									<div class="col-sm-8"><select name="selector1" id="selector1" class="form-control1">
										<option>Lorem ipsum dolor sit amet.</option>
										<option>Dolore, ab unde modi est!</option>
										<option>Illum, fuga minus sit eaque.</option>
										<option>Consequatur ducimus maiores voluptatum minima.</option>
									</select></div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label">Multiple Select</label>
									<div class="col-sm-8">
										<select multiple="" class="form-control1">
											<option>Option 1</option>
											<option>Option 2</option>
											<option>Option 3</option>
											<option>Option 4</option>
											<option>Option 5</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="txtarea1" class="col-sm-2 control-label">Textarea</label>
									<div class="col-sm-8"><textarea name="txtarea1" id="txtarea1" cols="50" rows="4" class="form-control1"></textarea></div>
								</div>
								<div class="form-group">
									<label for="radio" class="col-sm-2 control-label">Radio</label>
									<div class="col-sm-8">
										<div class="radio block"><label><input type="radio" /> Unchecked</label></div>
										<div class="radio block"><label><input type="radio" checked="" /> Checked</label></div>
										<div class="radio block"><label><input type="radio" disabled="" /> Disabled Unchecked</label></div>
										<div class="radio block"><label><input type="radio" disabled="" checked="" /> Disabled Checked</label></div>
									</div>
								</div>
								<div class="form-group">
									<label for="radio" class="col-sm-2 control-label">Radio Inline</label>
									<div class="col-sm-8">
										<div class="radio-inline"><label><input type="radio" /> Unchecked</label></div>
										<div class="radio-inline"><label><input type="radio" checked="" /> Checked</label></div>
										<div class="radio-inline"><label><input type="radio" disabled="" /> Disabled Unchecked</label></div>
										<div class="radio-inline"><label><input type="radio" disabled="" checked="" /> Disabled Checked</label></div>
									</div>
								</div>
								<div class="form-group">
									<label for="smallinput" class="col-sm-2 control-label label-input-sm">Small Input</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1 input-sm" id="smallinput" placeholder="Small Input" />
									</div>
								</div>
								<div class="form-group">
									<label for="mediuminput" class="col-sm-2 control-label">Medium Input</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="mediuminput" placeholder="Medium Input" />
									</div>
								</div>
								<div class="form-group mb-n">
									<label for="largeinput" class="col-sm-2 control-label label-input-lg">Large Input</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1 input-lg" id="largeinput" placeholder="Large Input" />
									</div>
								</div>
							</form>
						</div>
					</div>
					
					<div class="bs-example" data-example-id="form-validation-states">
    <form>
      <div class="form-group has-success">
        <label class="control-label" for="inputSuccess1">Input with success</label>
        <input type="text" class="form-control1" id="inputSuccess1" />
      </div>
      <div class="form-group has-warning">
        <label class="control-label" for="inputWarning1">Input with warning</label>
        <input type="text" class="form-control1" id="inputWarning1" />
      </div>
      <div class="form-group has-error">
        <label class="control-label" for="inputError1">Input with error</label>
        <input type="text" class="form-control1" id="inputError1" />
      </div>
    </form>
  </div>
  <div class="panel-body panel-body-inputin">
		<form role="form" class="form-horizontal">
			<div class="form-group">
				<label class="col-md-2 control-label">Email Address</label>
				<div class="col-md-8">
					<div class="input-group in-grp1">							
						<span class="input-group-addon">
							<i class="fa fa-envelope-o"></i>
						</span>
						<input type="text" class="form-control1" placeholder="Email Address" />
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Password</label>
				<div class="col-md-8">
					<div class="input-group in-grp1">
						<span class="input-group-addon">
							<i class="fa fa-key"></i>
						</span>
						<input type="password" class="form-control1" id="exampleInputPassword1" placeholder="Password" />
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Email Address</label>
				<div class="col-md-8">
					<div class="input-group input-icon right in-grp1">
						<span class="input-group-addon">
							<i class="fa fa-envelope-o"></i>
						</span>
						<input id="email" class="form-control1" type="text" placeholder="Email Address" />
					</div>
				</div>
				<div class="col-sm-2 jlkdfj1">
					<p class="help-block">With tooltip</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Password</label>
				<div class="col-md-8">
					<div class="input-group input-icon right in-grp1">
						<span class="input-group-addon">
							<i class="fa fa-key"></i>
						</span>
						<input type="password" class="form-control1" placeholder="Password" />
					</div>
				</div>
				<div class="col-sm-2 jlkdfj1">
					<p class="help-block">With tooltip</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group has-success">
				<label class="col-md-2 control-label">Input Addon Success</label>
				<div class="col-md-8">
					<div class="input-group input-icon right in-grp1">
						<span class="input-group-addon">
							<i class="fa fa-envelope-o"></i>
						</span>
						<input id="email" class="form-control1" type="text" placeholder="Email Address" />
					</div>
				</div>
				<div class="col-sm-2 jlkdfj1">
					<p class="help-block">Email is valid!</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group has-error">
				<label class="col-md-2 control-label">Input Addon Error</label>
				<div class="col-md-8">
					<div class="input-group input-icon right in-grp1">
						<span class="input-group-addon">
							<i class="fa fa-key"></i>
						</span>
						<input type="password" class="form-control1" placeholder="Password" />
					</div>
				</div>
				<div class="col-sm-2 jlkdfj1">
					<p class="help-block">Error!</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Checkbox Addon</label>
				<div class="col-md-8">
					<div class="input-group in-grp1">
						<div class="input-group-addon"><input type="checkbox" /></div>
						<input type="text" class="form-control1" />
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Checkbox Addon</label>
				<div class="col-md-8">
					<div class="input-group in-grp1">
						<input type="text" class="form-control1" />
						<div class="input-group-addon"><input type="checkbox" /></div>
						
					</div>
				</div>
				<div class="col-sm-2 jlkdfj1">
					<p class="help-block">Checkbox on right</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Radio Addon</label>
				<div class="col-md-8">
					<div class="input-group in-grp1">
						<div class="input-group-addon"><input type="radio" /></div>
						<input type="text" class="form-control1" />
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Radio Addon</label>
				<div class="col-md-8">
					<div class="input-group in-grp1">
						<input type="text" class="form-control1" />
						<div class="input-group-addon"><input type="radio" /></div>
						
					</div>
				</div>
				<div class="col-sm-2 jlkdfj1">
					<p class="help-block">Radio on right</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label">Input Processing</label>
				<div class="col-md-8">
					<div class="input-icon right spinner">
						<i class="fa fa-fw fa-spin fa-spinner"></i>
						<input id="email" class="form-control1" type="text" placeholder="Processing..." />
					</div>
				</div>
				<div class="col-sm-2">
					<p class="help-block">Processing right</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="form-group mb-n">
				<label class="col-md-2 control-label">Readonly</label>
				<div class="col-md-8">
					<input type="text" class="form-control1" placeholder="Readonly" readonly="" />
				</div>
				<div class="clearfix"> </div>
			</div>
		</form>
	</div>
						<div class="bs-example" data-example-id="form-validation-states-with-icons">
						<form>
						  <div class="form-group has-success has-feedback">
							<label class="control-label" for="inputSuccess2">Input with success</label>
							<input type="text" class="form-control1" id="inputSuccess2" aria-describedby="inputSuccess2Status" />
							<span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span>
							<span id="inputSuccess2Status" class="sr-only">(success)</span>
						  </div>
						  <div class="form-group has-warning has-feedback">
							<label class="control-label" for="inputWarning2">Input with warning</label>
							<input type="text" class="form-control1" id="inputWarning2" aria-describedby="inputWarning2Status" />
							<span class="glyphicon glyphicon-warning-sign form-control-feedback" aria-hidden="true"></span>
							<span id="inputWarning2Status" class="sr-only">(warning)</span>
						  </div>
						  <div class="form-group has-error has-feedback">
							<label class="control-label" for="inputError2">Input with error</label>
							<input type="text" class="form-control1" id="inputError2" aria-describedby="inputError2Status" />
							<span class="glyphicon glyphicon-remove form-control-feedback" aria-hidden="true"></span>
							<span id="inputError2Status" class="sr-only">(error)</span>
						  </div>
						  <div class="form-group has-success has-feedback">
							<label class="control-label" for="inputGroupSuccess1">Input group with success</label>
							<div class="input-group input-group1">
							  <span class="input-group-addon">@</span>
							  <input type="text" class="form-control1" id="inputGroupSuccess1" aria-describedby="inputGroupSuccess1Status" />
							</div>
							<span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span>
							<span id="inputGroupSuccess1Status" class="sr-only">(success)</span>
						  </div>
						  <div class="form-group">
							<label for="exampleInputFile">File input</label>
							<input type="file" id="exampleInputFile" />
							<p class="help-block">Example block-level help text here.</p>
						  </div>
						  <div class="panel-footer">
							<div class="row">
								<div class="col-sm-8 col-sm-offset-2">
									<button class="btn-success btn">Submit</button>
									<button class="btn-default btn">Cancel</button>
									<button class="btn-inverse btn">Reset</button>
								</div>
							</div>
						 </div>
						</form>
					  </div>
				</div>
			</div>
		</div>
		<!--footer section start-->
			<footer>
			   <p>&copy 2015 Easy Admin Panel. All Rights Reserved | Design by <a href="../http://balajisoftwaresolution.com/" target="_blank">Balaji Software Solution</a></p>
			</footer>
        <!--footer section end-->
	</section>
	
<script src="../js/jquery.nicescroll.js"></script>
<script src="../js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="../js/bootstrap.min.js"></script>
</body>
</html>