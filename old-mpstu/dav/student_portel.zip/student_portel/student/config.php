<?php
class payment_config{
	var $Url = "https://payment.atomtech.in/paynetz/epi/fts";
	var $Login="29062";
	var $Password="DAV@1234";
	var $MerchantName="ATOM";
	var $TxnCurr="INR";
	var $TxnScAmt="0";
}
?>