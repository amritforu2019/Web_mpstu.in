<?php
 error_reporting(0);
 session_start();

require_once"config.inc.php";
require_once"validate_eng.php";
$qry_global=mysql_query("select * from tbl_setting  ")or die(mysql_error());
$global_fetch=mysql_fetch_array($qry_global);
$SITE_NAME= stripslashes($global_fetch['site_name']);
$SITE_URL= stripslashes($global_fetch['site_url']);
$SITE_NAME_SHORT= stripslashes($global_fetch['site_short_name']);
$EMAIL_ID=stripslashes($global_fetch['email']);
$phone=stripslashes($global_fetch['phone']);
$unit=stripslashes($global_fetch['unit']);
$ADDRESS=stripslashes($global_fetch['destag']);
$AUTHOR=stripslashes($global_fetch['metatag']);
$MAP=stripslashes($global_fetch['contenttag']);
$PHONE_NO=stripslashes($global_fetch['unit']);
$DESCRIPTION=stripslashes($global_fetch['destag']);
$F=stripslashes($global_fetch['f']);
$L=stripslashes($global_fetch['l']);
$T=stripslashes($global_fetch['t']);
$Y=stripslashes($global_fetch['y']);
$G=stripslashes($global_fetch['g']);
$flip=stripslashes($global_fetch['flip']);
$amaz=stripslashes($global_fetch['amaz']);
$snap=stripslashes($global_fetch['snap']);

$PORT=stripslashes($global_fetch['port']);
$HOST=stripslashes($global_fetch['host']);
$MPASS=stripslashes($global_fetch['mpass']);
$WEBMAIL=stripslashes($global_fetch['webmail']);

$msg_typ=stripslashes($global_fetch['msg_typ']);
$msg_contact=stripslashes($global_fetch['msg_contact']);
$msg_pass=stripslashes($global_fetch['msg_pass']);
$msg_sender_id=stripslashes($global_fetch['msg_sender_id']);

$SESSION_MIN = 10;
$current_year = date('Y');
 
 $ADMIN_HTML_TITLE=stripslashes($global_fetch['site_admin_title']);
// function for admin login validation
function master()
{
if(!isset($_SESSION['master']))
header("Location:index.php");
}

function validate_admindav()
{
if(!isset($_SESSION['master_davpgcvns']))
header("Location:index.php");
}

function validate_stddav()
{
if(!isset($_SESSION['sess_student_id']))
header("Location:../index.php");
}



function master_main()
{
if(!isset($_SESSION['master_main']))
header("Location:index.php");
}

function master_user()
{
if(!isset($_SESSION['master_user']))
header("Location:login.php");
}

function master_agent()
{
if(!isset($_SESSION['master_agent']))
header("Location:login.php");
}

function master_providers()
{
if(!isset($_SESSION['provider_email']))
header("Location:login.php");
}

// function for filter the string
function normal_filter($val)
{
return ucfirst(stripslashes($val));
}

function strip_filter($val, $size)
{
return substr(stripslashes(strip_tags($val)),0,$size);
}



function caps_filter($val)

{

return strtoupper(stripslashes($val));

}



function normalall_filter($val)

{

return ucwords(stripslashes($val));

}


function date_dmy($date)
{
  if($date!='' || $date!='0000-00-00 00:00:00')
  {
  $e=mysql_fetch_array(mysql_query("select convert_tz('$date','+00:00','+12:00')"));
  $date= $e[0];
  list($date_new,$time_new)=explode(" ",$date);
  list($y,$m,$d)=explode("-",$date_new);
  list($hr,$min,$sec)=explode(":",$time_new);
  return date("j M Y h:i A", time());
  }
}


// function for page handling

function get_qry_str($over_write_key = array(), $over_write_value= array())

{

	global $_GET;

	$m = $_GET;

	if(is_array($over_write_key)){

		$i=0;

		foreach($over_write_key as $key){

			$m[$key] = $over_write_value[$i];

			$i++;

		}

	}else{

		$m[$over_write_key] = $over_write_value;

	}

	$qry_str = qry_str($m);

	return $qry_str;

} 



function qry_str($arr, $skip = '')

{

	$s = "?";

	$i = 0;

	foreach($arr as $key => $value) {

		if ($key != $skip) {

			if(is_array($value)){

				foreach($value as $value2){

					if ($i == 0) {

						$s .= "$key%5B%5D=$value2";

					$i = 1;

					} else {

						$s .= "&$key%5B%5D=$value2";

					} 

				}		

			}else{

				if ($i == 0) {

					$s .= "$key=$value";

					$i = 1;

				} else {

					$s .= "&$key=$value";

				} 

			}

		} 

	} 

	return $s;

} 



// function to include http 

function format_url($url)

{

	if(!preg_match('/http:\/\//',$url))

	{

		$url="http://".$url;

	}

	return $url;

}

// function to access description form content table
function enc($val){

if($val!='')

	{

	$new_val=base64_encode(base64_encode(base64_encode(base64_encode($val))));

	return $new_val;

	}

}



function dec($val){

if($val!='')

	{

	$org_val=base64_decode(base64_decode(base64_decode(base64_decode($val))));

	return $org_val;

	}

}

function show_descr($id)

{

	$row=mysql_fetch_array(mysql_query("select content from content where id='$id'"));

	return stripcslashes($row['content']);

}
function show_title($id)

{

	$row=mysql_fetch_array(mysql_query("select title from content where id='$id'"));

	return $row['title'];

}

function show_img($id)

{

	$row=mysql_fetch_array(mysql_query("select img from content where id='$id'"));

	return $row['img'];

}

function data_cutter($data,$cut)

{

	if(strlen(stripslashes($data))>$cut)
	{
	$cutdata=ucfirst(substr(stripslashes($data),0,$cut))."..."; }
	else {
	$cutdata=stripslashes($data); 
	}
	return $cutdata;

}



function calculate_bg()

{

	$c=mysql_query("select * from bg where status=1 limit 1")or die(mysql_error());

	$c1=mysql_fetch_array($c);

	if($c1['type']==1)

	{

		// image

		$image=$c1['blocation'];

		$x="style=\"background:url(admin/banner/ori/$image) center 0px no-repeat fixed #517bad;\"";

		return $x;

	}

	else

	{

		// bg color

		$color=$c1['burl'];

		$x=" bgcolor=$color";

		return $x;

	}	

}


function date_dm($date)
{
  if($date!='' || $date!='0000-00-00 00:00:00')
  {
  $e=mysql_fetch_array(mysql_query("select convert_tz('$date','+00:00','+00:00')"));
  $date= $e[0];
  list($date_new,$time_new)=explode(" ",$date);
  list($y,$m,$d)=explode("-",$date_new);  
  return date("j M Y",mktime(0,0,0,$m,$d,$y));
  }
}


function curPageName() {
 return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}

$currentPG=curPageName(); 
//session_destroy();

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}


function get_ip() {
		//Just get the headers if we can or else use the SERVER global
		if ( function_exists( 'apache_request_headers' ) ) {
			$headers = apache_request_headers();
		} else {
			$headers = $_SERVER;
		}
		//Get the forwarded IP if it exists
		if ( array_key_exists( 'X-Forwarded-For', $headers ) && filter_var( $headers['X-Forwarded-For'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$the_ip = $headers['X-Forwarded-For'];
		} elseif ( array_key_exists( 'HTTP_X_FORWARDED_FOR', $headers ) && filter_var( $headers['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 )
		) {
			$the_ip = $headers['HTTP_X_FORWARDED_FOR'];
		} else {
			
			$the_ip = filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
		}
		return $the_ip;
	}
	
	function ip_store($ip)
	{
	$qry_ip=mysql_query("select * from log_data where ip='$ip'")or die(mysql_error());
	$count_ip=mysql_num_rows($qry_ip);
	if($count_ip>0)
	{
    	$global_ip=mysql_fetch_array($qry_ip);
		$ip_open=$global_ip['count']+1;
   		mysql_query("update log_data set count='$ip_open',dt='".date("Y-m-d")."' where ip='$ip'");
	}
	else
	{
	mysql_query("insert into log_data set count='1',dt='".date("Y-m-d")."',ip='$ip'");
	}
	}
	
	
	
	function sms_sender($typ,$contact,$pass,$sender_id,$msg,$mob)
	{
	if($typ==1)
	{
		$text=$msg;
	    $data = "username=amitsoft&password=amit123@&sender=SVSSMS&to=".$mob."&message=".$text."&reqid=1&format={json|text}"; 
		$ch = curl_init('http://www.smssigma.com/API/WebSMS/Http/v1.0a/index.php?'); 
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch); 
		curl_close($ch);
	}
	if($typ==2)
	{
		$sendsms = str_replace(' ', '+',  $msg);
$url = "http://www.smssigma.com/API/WebSMS/Http/v1.0a/index.php?username=amitsoft&password=amit123@&sender=SVSSMS&to=".$mob."&message=".$text."&reqid=1&format={json|text}"; 
        $ret = file($url);
        $send = explode(":",$ret[0]);
if ($send[0] == "ID") { echo "successnmessage ID: ". $send[1];       } 
		
	}
	}
	
	
	function convert_number_to_words($number) {
    
    $hyphen      = '-';
    $conjunction = ' and ';
    $separator   = ', ';
    $negative    = 'negative ';
    $decimal     = ' point ';
    $dictionary  = array(
        0                   => 'Zero',
        1                   => 'One',
        2                   => 'Two',
        3                   => 'Three',
        4                   => 'Four',
        5                   => 'Five',
        6                   => 'Six',
        7                   => 'Seven',
        8                   => 'Eight',
        9                   => 'Nine',
        10                  => 'Ten',
        11                  => 'Eleven',
        12                  => 'Twelve',
        13                  => 'Thirteen',
        14                  => 'Fourteen',
        15                  => 'Fifteen',
        16                  => 'Sixteen',
        17                  => 'Seventeen',
        18                  => 'Eighteen',
        19                  => 'Nineteen',
        20                  => 'Twenty',
        30                  => 'Thirty',
        40                  => 'Fourty',
        50                  => 'Fifty',
        60                  => 'Sixty',
        70                  => 'Seventy',
        80                  => 'Eighty',
        90                  => 'Ninety',
        100                 => 'Hundred',
        1000                => 'Thousand',
        1000000             => 'Million',
        1000000000          => 'Billion',
        1000000000000       => 'Trillion',
        1000000000000000    => 'Quadrillion',
        1000000000000000000 => 'Quintillion'
    );
    
    if (!is_numeric($number)) {
        return false;
    }
    
    if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
        // overflow
        trigger_error(
            'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
            E_USER_WARNING
        );
        return false;
    }

    if ($number < 0) {
        return $negative . convert_number_to_words(abs($number));
    }
    
    $string = $fraction = null;
    
    if (strpos($number, '.') !== false) {
        list($number, $fraction) = explode('.', $number);
    }
    
    switch (true) {
        case $number < 21:
            $string = $dictionary[$number];
            break;
        case $number < 100:
            $tens   = ((int) ($number / 10)) * 10;
            $units  = $number % 10;
            $string = $dictionary[$tens];
            if ($units) {
                $string .= $hyphen . $dictionary[$units];
            }
            break;
        case $number < 1000:
            $hundreds  = $number / 100;
            $remainder = $number % 100;
            $string = $dictionary[$hundreds] . ' ' . $dictionary[100];
            if ($remainder) {
                $string .= $conjunction . convert_number_to_words($remainder);
            }
            break;
        default:
            $baseUnit = pow(1000, floor(log($number, 1000)));
            $numBaseUnits = (int) ($number / $baseUnit);
            $remainder = $number % $baseUnit;
            $string = convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
            if ($remainder) {
                $string .= $remainder < 100 ? $conjunction : $separator;
                $string .= convert_number_to_words($remainder);
            }
            break;
    }
    
    if (null !== $fraction && is_numeric($fraction)) {
        $string .= $decimal;
        $words = array();
        foreach (str_split((string) $fraction) as $number) {
            $words[] = $dictionary[$number];
        }
        $string .= implode(' ', $words);
    }
    
    return $string;
}
?>