<?php
 
 	 $DB["host"]   = "localhost";
	
	/* $DB["dbName"] = "look2get_newdatalook";	 
	 $DB["user"]   = "look2get_userget";
	 $DB["pass"]   = "6Cah,AzuiPNV";*/
	
	 $DB["dbName"] = "a6feed8d_std_data_port";	 
	 $DB["user"]   = "a6feed8d_stduser";
	 $DB["pass"]   = "U2NP^t}nXpzG";
	 $link = mysql_pconnect($DB["host"],$DB["user"],$DB["pass"]) or die("Connection Failed");
	 mysql_select_db($DB["dbName"]);
?>